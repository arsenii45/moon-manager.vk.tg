let tg = window.Telegram.WebApp;

tg.expand();

let id = tg.initDataUnsafe.user.id
if (id !== undefined) {
  document.getElementById('idInput').placeholder = id;
} else {
  console.log("ID is undefined");
}

tg.enableClosingConfirmation();
let bgcolor = "#000000";
tg.setBackgroundColor(bgcolor);

let btn = tg.MainButton
btn.text = 'Отправить'
function handleButtonClick() {
  console.log('Main Button got clicked!');
}
btn.onClick(handleButtonClick)

btn.show()
btn.enable()