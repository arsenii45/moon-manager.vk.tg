import mysql.connector

mysql_config = {
    'host': '37.220.86.88',
    'user': 'admin',
    'password': 'Amir_0509',
    'database': 'main'
}