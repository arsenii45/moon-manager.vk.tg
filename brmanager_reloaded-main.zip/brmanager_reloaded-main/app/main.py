import flet as ft
import asyncio
from flet import AppBar, ElevatedButton, Page, Text, View, colors, IconButton, icons, alignment, Row, \
    CrossAxisAlignment, MainAxisAlignment, ButtonStyle, ScrollMode, Column
import logging
import os
import telebot
from positions import *
from datetime import datetime
import pytz
import time as t
import mysql.connector

# import requests
import gspread

mysql_config = {
    'host': '37.220.86.88',
    'user': 'admin',
    'password': 'Amir_0509',
    'database': 'main'
}

conn = mysql.connector.connect(**mysql_config)
cursor = conn.cursor()
conn.autocommit = True

moscow_tz = pytz.timezone('Europe/Moscow')
time = datetime.now(moscow_tz).strftime("%d/%m/%Y %H:%M:%S")

logging.basicConfig(filename='../bot.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(funcName)s - %(message)s')
bot = telebot.TeleBot("6561602243:AAHvhoS37axZdYv7pdUJeDxQfQfK4CEm-xU")


# client.start()


def main(page: Page):
    page.title = "Manager | Console"
    page.theme_mode = 'dark'
    page.scroll = "adaptive"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    def get_nickname(user_id):
        cursor.execute("SELECT nickname FROM users WHERE user_id = %s", (user_id,))
        result = cursor.fetchone()

        if result:
            return result[0]

    def get_current_position(nickname):
        cursor.execute("SELECT current_position FROM users WHERE nickname = %s", (nickname,))
        result = cursor.fetchone()

        if result:
            return result[0]

    def get_user_id(nickname):
        cursor.execute("SELECT user_id FROM users WHERE nickname = %s", (nickname,))
        result = cursor.fetchone()
        if result:
            return result[0]

    def get_server(nickname):
        cursor.execute("SELECT server FROM users WHERE nickname = %s", (nickname,))
        result = cursor.fetchone()

        if result:
            return result[0]

    def change_theme(e):
        page.theme_mode = 'light' if page.theme_mode == 'dark' else 'dark'
        page.update()

    # not used anymore
    def go_to_user(user):
        return lambda e: page.go(f"/users/{user}")

    def validate(e):
        if all([user_login.value, user_pass.value]):
            btn_auth.disabled = False
        else:
            btn_auth.disabled = True

        page.update()

    def validate_data_type(e):
        if all(data_type_field.value):
            data_field_btn.disabled = False
        else:
            data_field_btn.disabled = True

    def validate_delete(e):
        if all(delete_type_field.value):
            delete_type_button.disabled = False
        else:
            delete_type_button.disabled = True

    def validate_punish(e):
        if all(punish_data_field2.value):
            punish_data_btn.disabled = False
        else:
            punish_data_btn.disabled = True

        page.update()

    def neaktiv_handle(id, status):
        admin_nick = page.client_storage.get("nickname")
        moscow_tz = pytz.timezone('Europe/Moscow')
        timestamp = datetime.now(moscow_tz).strftime("%d/%m/%Y %H:%M:%S")
        cursor.execute("SELECT server,department,nickname,time,reason,user_id,num_days FROM neaktiv WHERE id=%s", (id,))
        id_res = cursor.fetchone()
        if id_res:
            server = id_res[0]
            department = id_res[1]
            username = id_res[2]
            time = id_res[3]
            reason = id_res[4]
            user_id = id_res[5]
            num_days = id_res[6]
        else:
            page.snack_bar = ft.SnackBar(ft.Text('Не удалось получить информацию(serv,dep).'), bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return

        if department == 'Администрация':
            table_column = 'admin'
        elif department == 'АП':
            table_column = 'helper'
        else:
            table_column = 'leader'
        cursor.execute(f"SELECT {table_column}_table FROM server_info WHERE server = %s", (server,))
        res_t = cursor.fetchone()
        if res_t:
            table_link = res_t[0]
        else:
            page.snack_bar = ft.SnackBar(ft.Text(f'Невозможно найти таблицу для отдела: {department}'),
                                         bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return
        cursor.execute(f"SELECT chat_{table_column}_id FROM server_info WHERE server = %s", (server,))
        res_c = cursor.fetchone()
        if res_c:
            management_chat = res_c[0]
        else:
            page.snack_bar = ft.SnackBar(ft.Text(f'Невозможно найти чат для отдела: {department}'),
                                         bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return
        if status == 'approve':
            try:
                page.snack_bar = ft.SnackBar(ft.Text('Процесс начался.'), bgcolor=ft.colors.ORANGE)
                page.snack_bar.open = True
                page.update()
                t.sleep(2)
                gc = gspread.service_account(filename='credentials.json')
                sh = gc.open_by_url(table_link)
                worksheet = sh.worksheet("Учётность состава")
                header_row = worksheet.row_values(1)
                column_indices = {column_name: index + 1 for index, column_name in enumerate(header_row)}
                cells = worksheet.findall(username)
                value_to_update = f"{time},причина:{reason}"
                if cells:
                    cell = cells[0]
                    row = cell.row
                    worksheet.update_cell(row, column_indices['Текущий/Последний неактив'], value_to_update)
                    cursor.execute(f"UPDATE neaktiv SET status=%s,reviewed_by=%s,reviewed_at = %s WHERE id = %s",
                                   ('Одобрено', admin_nick, timestamp, id,))
                    conn.commit()
                    admin_id = get_user_id(admin_nick)
                    admin_link = f'<a href="tg://user?id={admin_id}">{admin_nick}</a>'
                    info_message += f"Администратор <b>{admin_link}</b> одобрил неактив для пользователя <b>{username}.</b>\n"
                    info_message += f"<b>Инфорация о неактиве</b>:\n\n"
                    info_message += f'<b>Даты неактива:</b> {time}\n<b>Причина неактива:</b> {reason}'
                    info_message2 = f"Ваша заявка на неактив была одобрена администратором — <b>{admin_nick}</b>\n\n<b>Инфорация о неактиве</b>:\n\n<b>Даты неактива:</b> {time}\n<b>Причина неактива:</b> {reason}"
                    bot.send_message(management_chat, info_message, parse_mode="HTML")
                    bot.send_message(user_id, info_message2, parse_mode="HTML")
                    page.snack_bar = ft.SnackBar(ft.Text('Успешно!'), bgcolor=ft.colors.GREEN)
                    page.snack_bar.open = True
                    page.update()
                    page.go("/neaktiv")
                else:
                    page.snack_bar = ft.SnackBar(ft.Text(f'Пользователь {username} не найден в таблице.'),
                                                 bgcolor=ft.colors.RED)
                    page.snack_bar.open = True
                    page.update()
                    return
            except Exception as e:
                page.snack_bar = ft.SnackBar(ft.Text(f'😔Произошла ошибка: {e}'), bgcolor=ft.colors.RED)
                page.snack_bar.open = True
                page.update()
        else:
            cursor.execute("UPDATE neaktiv SET status = %s,reviewed_by = %s,reviewed_at = %s WHERE id = %s",
                           ('Отказано', admin_nick, timestamp, id,))
            conn.commit()
            page.snack_bar = ft.SnackBar(ft.Text('Успешно!'), bgcolor=ft.colors.GREEN)
            page.snack_bar.open = True
            page.update()
            admin_id = get_user_id(admin_nick)
            admin_link = f'<a href="tg://user?id={admin_id}">{admin_nick}</a>'
            bot.send_message(user_id, f"Ваша заявка на неактив была отказана администратором - <b>{admin_nick}</b>",
                             parse_mode="HTML")
            bot.send_message(management_chat,
                             f"Администратор <b>{admin_link}</b> отказал заявку <b>{username}</b> на неактив.",
                             parse_mode="HTML")
            page.go("/neaktiv")

        page.update()

    def promotion_handle(id, status, reason):
        admin_nick = page.client_storage.get("nickname")
        moscow_tz = pytz.timezone('Europe/Moscow')
        time = datetime.now(moscow_tz).strftime("%d/%m/%Y %H:%M:%S")
        cursor.execute("SELECT server,nickname,current_position,desired_position,user_id FROM promotions WHERE id=%s",
                       (id,))
        id_res = cursor.fetchone()
        if id_res:
            server = id_res[0]
            department = 'Администрация'
            username = id_res[1]
            current_position = id_res[2]
            desired_position = id_res[3]
            user_id = id_res[4]
        else:
            page.snack_bar = ft.SnackBar(ft.Text('Не удалось получить информацию(serv,dep).'), bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return

        table_column = 'admin'
        cursor.execute(f"SELECT {table_column}_table FROM server_info WHERE server = %s", (server,))
        res_t = cursor.fetchone()
        if res_t:
            table_link = res_t[0]
        else:
            page.snack_bar = ft.SnackBar(ft.Text(f'Невозможно найти таблицу для отдела: {department}'),
                                         bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return
        cursor.execute(f"SELECT chat_{table_column}_id FROM server_info WHERE server = %s", (server,))
        res_c = cursor.fetchone()
        if res_c:
            management_chat = res_c[0]
        else:
            page.snack_bar = ft.SnackBar(ft.Text(f'Невозможно найти чат для отдела: {department}'),
                                         bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return
        if status == 'approve':
            try:
                page.snack_bar = ft.SnackBar(ft.Text('Процесс начался.'), bgcolor=ft.colors.ORANGE)
                page.snack_bar.open = True
                page.update()
                t.sleep(2)
                gc = gspread.service_account(filename='credentials.json')
                sh = gc.open_by_url(table_link)
                worksheet = sh.worksheet("Учётность состава")
                header_row = worksheet.row_values(1)
                column_indices = {column_name: index + 1 for index, column_name in enumerate(header_row)}
                cells = worksheet.findall(username)
                value_to_update = f"{time}"
                if cells:
                    cell = cells[0]
                    row = cell.row
                    worksheet.update_cell(row, column_indices['Последние повышения'], value_to_update)
                    cursor.execute(f"UPDATE promotions SET status=%s,reviewed_by=%s,reviewed_at = %s WHERE id = %s",
                                   ('Одобрено', admin_nick, time, id,))
                    conn.commit()
                    cursor.execute("UPDATE users SET current_position = %s,last_promotion = %s WHERE user_id = %s",
                                   (desired_position, time, user_id,))
                    conn.commit()
                    admin_id = get_user_id(admin_nick)
                    admin_link = f'<a href="tg://user?id={admin_id}">{admin_nick}</a>'
                    info_message = f"Администратор <b>{admin_link}</b> одобрил повышения для пользователя <b>{username}.\n\n</b>\n"
                    info_message += f"<b>Инфорация о заявки</b>:\n\n"
                    info_message += f'<b>Должность до повышения: {current_position}</b>\n\n<b>Новая должность: {desired_position}</b>'
                    info_message2 = f'Ваша заявка на повышения была одобрена администратором — <b>{admin_nick}</b>.\n<b>Инфорация о заявки</b>:\n\n<b>Должность до повышения: {current_position}</b>\n\n<b>Новая должность: {desired_position}</b>'
                    bot.send_message(management_chat, info_message, parse_mode="HTML")
                    bot.send_message(user_id, info_message2, parse_mode="HTML")
                    page.snack_bar = ft.SnackBar(ft.Text('Успешно!'), bgcolor=ft.colors.GREEN)
                    page.snack_bar.open = True
                    page.update()
                    page.go("/promotions")
                else:
                    page.snack_bar = ft.SnackBar(ft.Text(f'Пользователь {username} не найден в таблице.'),
                                                 bgcolor=ft.colors.RED)
                    page.snack_bar.open = True
                    page.update()
                    return
            except Exception as e:
                page.snack_bar = ft.SnackBar(ft.Text(f'😔Произошла ошибка: {e}'), bgcolor=ft.colors.RED)
                page.snack_bar.open = True
                page.update()
                return
        elif status == 'reject':
            page.go(f"/promotions/{id}/p_reject")

        else:
            if reason is None:
                page.snack_bar = ft.SnackBar(ft.Text('Необходимо выбрать причину!'), bgcolor=ft.colors.RED)
                page.snack_bar.open = True
                page.update()
                return
            page.snack_bar = ft.SnackBar(ft.Text('Процесс начался!'), bgcolor=ft.colors.ORANGE)
            page.snack_bar.open = True
            page.update()
            cursor.execute(
                "UPDATE promotions SET status = %s,reviewed_by = %s,reviewed_at = %s,reason = %s WHERE id = %s",
                ('Отказано', admin_nick, time, reason, id,))
            conn.commit()
            page.snack_bar = ft.SnackBar(ft.Text('Успешно!'), bgcolor=ft.colors.GREEN)
            page.snack_bar.open = True
            page.update()
            admin_id = get_user_id(admin_nick)
            admin_link = f'<a href="tg://user?id={admin_id}">{admin_nick}</a>'
            bot.send_message(user_id,
                             f"Ваша заявка на повышения была отказана - <b>{admin_nick}</b>\n\n<b>Причина:</b> {reason}",
                             parse_mode="HTML")
            bot.send_message(management_chat,
                             f"Администратор <b>{admin_link}</b> отказал заявку <b>{username}</b> на повышения\n\n<b>Причина:</b> {reason}.",
                             parse_mode="HTML")
            page.go("/promotions")

        page.update()

    def property_transfer_handle(id, status):
        admin_nick = page.client_storage.get("nickname")
        moscow_tz = pytz.timezone('Europe/Moscow')
        time = datetime.now(moscow_tz).strftime("%d/%m/%Y %H:%M:%S")
        cursor.execute(
            "SELECT server,nickname,p_nickname,info,user_id,goss_price,dolg,dolg_date FROM property_transfer WHERE id=%s",
            (id,))
        id_res = cursor.fetchone()
        if id_res:
            server = id_res[0]
            department = 'Администрация'
            username = id_res[1]
            p_nickname = id_res[2]
            info = id_res[3]
            user_id = id_res[4]
            goss_price = id_res[5]
            dolg = id_res[6]
            dolg_date = id_res[7]
        else:
            page.snack_bar = ft.SnackBar(ft.Text('Не удалось получить информацию(serv,dep).'), bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return

        table_column = 'admin'
        cursor.execute(f"SELECT {table_column}_table FROM server_info WHERE server = %s", (server,))
        res_t = cursor.fetchone()
        if res_t:
            table_link = res_t[0]
        else:
            page.snack_bar = ft.SnackBar(ft.Text(f'Невозможно найти таблицу для отдела: {department}'),
                                         bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return
        cursor.execute(f"SELECT chat_{table_column}_id FROM server_info WHERE server = %s", (server,))
        res_c = cursor.fetchone()
        if res_c:
            management_chat = res_c[0]
        else:
            page.snack_bar = ft.SnackBar(ft.Text(f'Невозможно найти чат для отдела: {department}'),
                                         bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return
        if status == 'approve':
            try:
                page.snack_bar = ft.SnackBar(ft.Text('Процесс начался!'), bgcolor=ft.colors.ORANGE)
                page.snack_bar.open = True
                page.update()
                cursor.execute(f"UPDATE property_transfer SET status=%s,reviewed_by=%s,reviewed_at = %s WHERE id = %s",
                               ('Одобрено', admin_nick, time, id,))
                conn.commit()
                # cursor.execute("UPDATE users SET current_position = %s,last_promotion = %s WHERE user_id = %s",(desired_position,time,user_id,))
                # conn.commit()
                admin_id = get_user_id(admin_nick)
                admin_link = f'<a href="tg://user?id={admin_id}">{admin_nick}</a>'
                info_message = f"Администратор <b>{admin_link}</b> одобрил транзакцию с игроком для пользователя <b>{username}.\n\n</b>\n"
                info_message += f"<b>Инфорация о заявки</b>:\n\n"
                info_message += f'<b>Проводил транзакцию с:</b> {p_nickname}\n<b>Информация о транзакции:</b> {info}\n'
                info_message += f"<b>Госс.стоимость предмета:</b> {goss_price}\n\n"
                info_message += f"<b>Сумма долга:</b> {dolg}\n<b>Дата возрата долга:</b> {dolg_date}"
                info_message2 = f'Ваша заявка на проведение транзакции с игроком <b>{p_nickname}</b> была одобрена администратором — <b>{admin_nick}</b>.\n<b>Инфорация о заявки</b>:\n\n<b>Ник игрока:</b> {p_nickname}\n<b>Информация о транзакции:</b> {info}\n'
                info_message2 += f"<b>Госс.стоимость предмета:</b> {goss_price}\n\n"
                info_message2 += f"<b>Сумма долга:</b> {dolg}\n<b>Дата возрата долга:</b> {dolg_date}"
                bot.send_message(management_chat, info_message, parse_mode="HTML")
                bot.send_message(user_id, info_message2, parse_mode="HTML")
                page.snack_bar = ft.SnackBar(ft.Text('Успешно!'), bgcolor=ft.colors.GREEN)
                page.snack_bar.open = True
                page.update()
                page.go("/property_transfer")
            except Exception as e:
                page.snack_bar = ft.SnackBar(ft.Text(f'😔Произошла ошибка: {e}'), bgcolor=ft.colors.RED)
                page.snack_bar.open = True
                page.update()
                return
        elif status == 'reject':
            page.snack_bar = ft.SnackBar(ft.Text('Процесс начался!'), bgcolor=ft.colors.ORANGE)
            page.snack_bar.open = True
            page.update()
            cursor.execute("UPDATE property_transfer SET status = %s,reviewed_by = %s,reviewed_at = %s WHERE id = %s",
                           ('Отказано', admin_nick, time, id,))
            conn.commit()
            page.snack_bar = ft.SnackBar(ft.Text('Успешно!'), bgcolor=ft.colors.GREEN)
            page.snack_bar.open = True
            page.update()
            admin_id = get_user_id(admin_nick)
            admin_link = f'<a href="tg://user?id={admin_id}">{admin_nick}</a>'
            bot.send_message(user_id, f"Ваша заявка на проведение транзакции была отказана - <b>{admin_nick}</b>.",
                             parse_mode="HTML")
            bot.send_message(management_chat,
                             f"Администратор <b>{admin_link}</b> отказал заявку <b>{username}</b> на транзакцию с игроком {p_nickname}.",
                             parse_mode="HTML")
            page.go("/property_transfer")
        page.update()

    def update_data():
        path_parts = page.route.split("/")
        username = path_parts[1]
        info_type = page.route.split("/")[3]
        admin_nick = page.client_storage.get("nickname")
        if info_type == 'age':
            column_to_update = 'age'
            data_type = 'Возраст'
        elif info_type == 'nickname':
            column_to_update = 'nickname'
            data_type = 'NickName'
        elif info_type == 'rep':
            column_to_update = 'report'
            data_type = 'Ответы'
        elif info_type == 'online':
            column_to_update = 'online'
            data_type = 'Online'

        try:
            # page.update()
            cursor.execute("SELECT department,server,user_id FROM users WHERE nickname = %s", (username,))
            result = cursor.fetchone()
            if result:
                department = result[0]
                server = result[1]
                user_id = result[2]
                if department == 'Администрация':
                    table_column = 'admin'
                elif department == 'АП':
                    table_column = 'helper'
                else:
                    table_column = 'leader'

            else:
                page.snack_bar = ft.SnackBar(ft.Text(f'Невозможно найти отдел пользователя: {username}'),
                                             bgcolor=ft.colors.RED)
                page.snack_bar.open = True
            cursor.execute(f"SELECT {table_column}_table FROM server_info WHERE server = %s", (server,))
            res_t = cursor.fetchone()
            if res_t:
                table_link = res_t[0]
            else:
                page.snack_bar = ft.SnackBar(ft.Text(f'Невозможно найти таблицу для отдела: {department}'),
                                             bgcolor=ft.colors.RED)
                page.snack_bar.open = True
            cursor.execute(f"SELECT chat_{table_column}_id FROM server_info WHERE server = %s", (server,))
            res_c = cursor.fetchone()
            if res_c:
                management_chat = res_c[0]
            else:
                page.snack_bar = ft.SnackBar(ft.Text(f'Невозможно найти чат для отдела: {department}'),
                                             bgcolor=ft.colors.RED)
                page.snack_bar.open = True
            gc = gspread.service_account(filename='credentials.json')
            sh = gc.open_by_url(table_link)
            worksheet = sh.worksheet("Учётность состава")
            header_row = worksheet.row_values(1)
            column_indices = {column_name: index + 1 for index, column_name in enumerate(header_row)}
            cells = worksheet.findall(username)
            if cells:
                cell = cells[0]
                row = cell.row
                worksheet.update_cell(row, column_indices[f'{data_type}'], data_type_field.value)
                cursor.execute(f"UPDATE users SET {column_to_update} = %s WHERE nickname = %s",
                               (data_type_field.value, username,))
                conn.commit()
                admin_id = get_user_id(admin_nick)
                admin_link = f'<a href="tg://user?id={admin_id}">{admin_nick}</a>'
                info_message = f'Администратор <b>{admin_link}</b> изменил {data_type} для пользователя <b>{username}</b>.\n'
                info_message += f'Новое значения: {data_type_field.value}'
                info_message2 = f'Информация о вас была изменена администратором <b>{admin_nick}</b>\n'
                info_message2 += f'Ваш {data_type} был изменен на {data_type_field.value}'
                bot.send_message(management_chat, info_message, parse_mode="HTML")
                bot.send_message(user_id, info_message2, parse_mode="HTML")
                data_field_btn.text = 'Успешно!'
                data_field_btn.width = 200
                data_field_btn.icon = 'GPP_GOOD_ROUNDED'
            else:
                page.snack_bar = ft.SnackBar(ft.Text(f'Пользователь {username} не найден в таблице.'),
                                             bgcolor=ft.colors.RED)
                page.snack_bar.open = True
        except Exception as e:
            page.snack_bar = ft.SnackBar(ft.Text(f'Ошибка при изменение: {e}'), bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            return

        page.update()

    def auth_user(e):
        cursor.execute("SELECT COUNT(*) FROM users WHERE nickname = %s", (user_login.value,))
        count = cursor.fetchone()[0]
        if count:
            password = get_user_password(user_login.value)

            if user_pass.value == password:
                page.client_storage.set("loggedin", True)
                page.client_storage.set("nickname", f"{user_login.value}")
                page.go("/")
            else:
                page.snack_bar = ft.SnackBar(ft.Text('Вы указали неккоректный пароль!'), bgcolor=ft.colors.RED)
                page.snack_bar.open = True
        else:
            page.snack_bar = ft.SnackBar(ft.Text('Неверно введеные данные!'), bgcolor=ft.colors.RED)
            page.snack_bar.open = True
        page.update()

    def get_user_password(nickname):
        cursor.execute("SELECT admin_pass FROM users WHERE nickname = %s", (nickname,))
        result = cursor.fetchone()

        if result:
            return result[0]

    def change_date(e):
        # date = datetime.strptime(date_picker.value, "%Y-%m-%d %H:%M:%S").strftime("%d/%m/%Y")
        date = date_picker.value.strftime("%d/%m/%Y %H:%M:%S")
        path_parts = page.route.split("/")
        username = path_parts[1]
        admin_nick = page.client_storage.get("nickname")
        page.snack_bar = ft.SnackBar(ft.Text('Процесс начался.'), bgcolor=ft.colors.ORANGE)
        page.snack_bar.open = True
        page.update()
        cursor.execute("SELECT server,department,created_at,user_id FROM users WHERE nickname=%s", (username,))
        id_res = cursor.fetchone()
        if id_res:
            server = id_res[0]
            department = id_res[1]
            created_at = id_res[2]
            user_id = id_res[3]
        else:
            page.snack_bar = ft.SnackBar(ft.Text('Не удалось получить информацию(serv,dep).'), bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return

        if department == 'Администрация':
            table_column = 'admin'
        elif department == 'АП':
            table_column = 'helper'
        else:
            table_column = 'leader'
        cursor.execute(f"SELECT {table_column}_table FROM server_info WHERE server = %s", (server,))
        res_t = cursor.fetchone()
        if res_t:
            table_link = res_t[0]
        else:
            page.snack_bar = ft.SnackBar(ft.Text(f'Невозможно найти таблицу для отдела: {department}'),
                                         bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return
        cursor.execute(f"SELECT chat_{table_column}_id FROM server_info WHERE server = %s", (server,))
        res_c = cursor.fetchone()
        if res_c:
            management_chat = res_c[0]
        else:
            page.snack_bar = ft.SnackBar(ft.Text(f'Невозможно найти чат для отдела: {department}'),
                                         bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return
        try:
            gc = gspread.service_account(filename='credentials.json')
            sh = gc.open_by_url(table_link)
            worksheet = sh.worksheet("Учётность состава")
            header_row = worksheet.row_values(1)
            column_indices = {column_name: index + 1 for index, column_name in enumerate(header_row)}
            cells = worksheet.findall(username)
            if cells:
                cell = cells[0]
                row = cell.row
                worksheet.update_cell(row, column_indices[f'Дата постановления'], date)
                admin_id = get_user_id(admin_nick)
                admin_link = f'<a href="tg://user?id={admin_id}">{admin_nick}</a>'
                user_message = f'Администратор <b>{admin_nick}</b> изменил вашу дату постановления на {date}'
                log_message = f'Администратор <b>{admin_link}</b> изменил дату постановления для пользователя {username} на {date}.'
                cursor.execute("UPDATE users SET created_at = %s WHERE nickname = %s", (date, username))
                conn.commit()
                page.snack_bar = ft.SnackBar(ft.Text(f'Успешно! Значение изменено на {date}'), bgcolor=ft.colors.GREEN)
                page.snack_bar.open = True
                page.update()
                bot.send_message(user_id, user_message, parse_mode="HTML")
                bot.send_message(management_chat, log_message, parse_mode="HTML")
            else:
                page.snack_bar = ft.SnackBar(ft.Text(f'😔 Не найден в таблице:{username}'), bgcolor=ft.colors.RED)
                page.snack_bar.open = True
                page.update()
        except Exception as e:
            page.snack_bar = ft.SnackBar(ft.Text(f'😔 Произошла ошибка:{e}'), bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return

    def date_picker_dismissed(e):
        pass

    def get_info_type(e):
        info = page.route.split("/")[3]
        if info:
            return info

    def delete_user():
        path_parts = page.route.split("/")
        nickname = path_parts[1]
        reason = delete_type_field.value
        admin_nick = page.client_storage.get("nickname")
        page.snack_bar = ft.SnackBar(ft.Text('Процесс начался.'), bgcolor=ft.colors.ORANGE)
        page.snack_bar.open = True
        page.update()
        cursor.execute("SELECT server,department FROM users WHERE nickname = %s", (nickname,))
        srv = cursor.fetchone()
        if srv:
            server = srv[0]
            department = srv[1]
        else:
            page.snack_bar = ft.SnackBar(ft.Text('Невозможно найти ваш сервер и отдел.'), bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return

        if department == 'Администрация':
            table_column = 'admin'
        elif department == 'АП':
            table_column = 'helper'
        else:
            table_column = 'leader'
        cursor.execute(f"SELECT {table_column}_table FROM server_info WHERE server = %s", (server,))
        res_t = cursor.fetchone()
        if res_t:
            table_link = res_t[0]
        else:
            page.snack_bar = ft.SnackBar(ft.Text(f'Невозможно найти таблицу для отдела: {department}'),
                                         bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return
        cursor.execute(f"SELECT chat_{table_column}_id FROM server_info WHERE server = %s", (server,))
        res_c = cursor.fetchone()
        if res_c:
            management_chat = res_c[0]
        else:
            page.snack_bar = ft.SnackBar(ft.Text(f'Невозможно найти чат для отдела: {department}'),
                                         bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return
        cursor.execute(f"SELECT discord,vk,forum,email FROM users WHERE nickname = %s", (nickname,))
        com_info = cursor.fetchone()
        if com_info:
            discord = com_info[0]
            vk = com_info[1]
            forum = com_info[2]
            email = com_info[3]
            vk_hyperlink = f'=HYPERLINK("{vk}", "VK")' if vk else ""
            discord_hyperlink = f'=HYPERLINK("{discord}", "Discord")' if discord else "0"
            forum_hyperlink = f'=HYPERLINK("{forum}", "Forum")' if forum else ""
            email_hyperlink = f'=HYPERLINK("{email}", "Email")' if email else ""
        else:
            page.snack_bar = ft.SnackBar(ft.Text(f'Невозможно найти данные {nickname} '), bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return

        try:
            gc = gspread.service_account(filename='credentials.json')
            sh = gc.open_by_url(table_link)
            worksheet = sh.worksheet("Учётность состава")
            header_row = worksheet.row_values(1)
            column_indices = {column_name: index + 1 for index, column_name in enumerate(header_row)}
            cells = worksheet.findall(nickname)
            if cells:
                cell = cells[0]
                row = cell.row
                values = worksheet.row_values(row)
                values[4] = time
                values[5] = admin_nick
                values.insert(6, reason)
                worksheet.delete_row(row)
                try:
                    worksheet2 = sh.worksheet("Учёт снятых")
                    worksheet2.insert_row(values, index=2)
                    cells = worksheet2.findall(nickname)
                    cell = cells[0]
                    row = cell.row
                    worksheet2.update_cell(row, 17, discord_hyperlink)
                    worksheet2.update_cell(row, 18, vk_hyperlink)
                    worksheet2.update_cell(row, 19, forum_hyperlink)
                    worksheet2.update_cell(row, 20, email_hyperlink)
                    user_id = get_user_id(nickname)
                    admin_id = get_user_id(admin_nick)

                    cursor.execute("DELETE FROM users WHERE nickname = %s", (nickname,))
                    conn.commit()
                    admin_link = f'<a href="tg://user?id={admin_id}">{admin_nick}</a>'
                    nickname_link = f'<a href="tg://user?id={user_id}">{nickname}</a>'
                    user_message = f'Вы были сняты с должности администратором - <b>{admin_nick}!</b>\n\nПричина: {reason}'
                    log_message = f'<b>{admin_link}</b> снял с должности пользователя <b>{nickname_link}</b>.\n\nПричина: {reason}'
                    bot.send_message(user_id, user_message, parse_mode="HTML")
                    bot.send_message(management_chat, log_message, parse_mode="HTML")
                    logging.info(f'{admin_nick} - Успешно снял {nickname}с должности, AdminDash  - {time}MSK')
                    page.snack_bar = ft.SnackBar(ft.Text(f'{nickname} успешно снят!'), bgcolor=ft.colors.GREEN)
                    page.snack_bar.open = True
                    page.update()
                    page.go("/")
                except Exception as e:
                    page.snack_bar = ft.SnackBar(ft.Text(f'😔 Произошла ошибка1:{e}'), bgcolor=ft.colors.RED)
                    page.snack_bar.open = True
                    page.update()
                    logging.info(f'{admin_nick} - Произошла ошибка: {e}, AdminDash  - {time}MSK')
                    return
            else:
                page.snack_bar = ft.SnackBar(ft.Text(f'😔 Не найден в таблице:{nickname}'), bgcolor=ft.colors.RED)
                page.snack_bar.open = True
                page.update()
                return
        except Exception as e:
            page.snack_bar = ft.SnackBar(ft.Text(f'😔 Произошла ошибка2:{e}'), bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            logging.info(f'{admin_nick} - Произошла ошибка: {e}, AdminDash  - {time}MSK')
            return

    def minus_click(e):
        punish_data_field.value = str(int(punish_data_field.value) - 1)
        page.update()

    def plus_click(e):
        punish_data_field.value = str(int(punish_data_field.value) + 1)
        page.update()

    def update_punish():
        path_parts = page.route.split("/")
        nickname = path_parts[0]
        punish_type = path_parts[2]
        num = int(punish_data_field.value)
        reason = punish_data_field2.value
        admin_nick = page.client_storage.get("nickname")
        page.snack_bar = ft.SnackBar(ft.Text('Процесс начался.'), bgcolor=ft.colors.ORANGE)
        page.snack_bar.open = True
        page.update()
        if punish_type == 'vig':
            table_punish = 'Выговоры'
        elif punish_type == 'pred':
            table_punish = 'Предупреждение'
        else:
            table_punish = 'Устники'
        cursor.execute(f"SELECT server,department,{punish_type},user_id FROM users WHERE nickname = %s", (nickname,))
        srv = cursor.fetchone()
        if srv:
            server = srv[0]
            department = srv[1]
            old_punish = srv[2]
            user_id = srv[3]
        else:
            page.snack_bar = ft.SnackBar(ft.Text('Невозможно найти ваш сервер и отдел.'), bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return
        if department == 'Администрация':
            table_column = 'admin'
        elif department == 'АП':
            table_column = 'helper'
        else:
            table_column = 'leader'
        cursor.execute(f"SELECT {table_column}_table FROM server_info WHERE server = %s", (server,))
        res_t = cursor.fetchone()
        if res_t:
            table_link = res_t[0]
        else:
            page.snack_bar = ft.SnackBar(ft.Text(f'Невозможно найти таблицу для отдела: {department}'),
                                         bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return
        cursor.execute(f"SELECT chat_{table_column}_id FROM server_info WHERE server = %s", (server,))
        res_c = cursor.fetchone()
        if res_c:
            management_chat = res_c[0]
        else:
            page.snack_bar = ft.SnackBar(ft.Text(f'Невозможно найти чат для отдела: {department}'),
                                         bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return
        try:
            gc = gspread.service_account(filename='credentials.json')
            sh = gc.open_by_url(table_link)
            worksheet = sh.worksheet("Учётность состава")
            header_row = worksheet.row_values(1)
            column_indices = {column_name: index + 1 for index, column_name in enumerate(header_row)}
            cells = worksheet.findall(nickname)
            if cells:
                cell = cells[0]
                row = cell.row
                new_value = old_punish + num
                admin_id = get_user_id(admin_nick)
                admin_link = f'<a href="tg://user?id={admin_id}">{admin_nick}</a>'
                worksheet.update_cell(row, column_indices[table_punish], new_value)
                cursor.execute(f"UPDATE users SET {punish_type} = %s WHERE nickname = %s", (new_value, nickname,))
                conn.commit()
                user_message = f'Администратор <b>{admin_nick}</b> выдал/снял ваше наказания.\n\nТип наказания: {table_punish}\nСтарое значения:{old_punish}\nНовое значения:{new_value}\nПричина:{reason}'
                log_message = f'Администратор <b>{admin_link}</b> выдал/снял наказания для пользователя {nickname}.\n\nТип наказания: {table_punish}\nСтарое значения:{old_punish}\nНовое значения:{new_value}\nПричина:{reason}'
                bot.send_message(user_id, user_message, parse_mode="HTML")
                bot.send_message(management_chat, log_message, parse_mode="HTML")
            else:
                page.snack_bar = ft.SnackBar(ft.Text(f'{nickname} не найден в таблице!'), bgcolor=ft.colors.RED)
                page.snack_bar.open = True
                page.update()
                return
        except Exception as e:
            page.snack_bar = ft.SnackBar(ft.Text(f'Произошла ошибка:{e}'), bgcolor=ft.colors.RED)
            page.snack_bar.open = True
            page.update()
            return

    user_login = ft.TextField(label='Nickname', width=200, on_change=validate)
    user_pass = ft.TextField(label='Password', password=True, width=200, on_change=validate)
    btn_auth = ft.OutlinedButton(text='Войти', width=200, on_click=auth_user, disabled=True)
    data_type_field = ft.TextField(label=f"Укажите новое значения", width=200, on_change=validate_data_type)
    data_field_btn = ft.OutlinedButton(text="Изменить", icon="change_circle", icon_color="green", width=200,
                                       disabled=True, on_click=lambda e: update_data())
    delete_type_field = ft.TextField(label=f"Укажите причину", width=200, on_change=validate_delete)
    delete_type_button = ft.OutlinedButton(text="Снять", icon="person_remove_alt_1", icon_color="red", width=200,
                                           disabled=True, on_click=lambda e: delete_user())
    punish_data_field = ft.TextField(label=f"Укажите кол-во", value="0", width=200, on_change=validate_punish,
                                     text_align=ft.TextAlign.CENTER, )
    punish_data_field2 = ft.TextField(label=f"Укажите причину", width=200, on_change=validate_punish, )
    punish_data_btn = ft.OutlinedButton(text="Изменить", icon="change_cirlce", icon_color="red", width=200,
                                        disabled=True, on_click=lambda e: update_punish())

    date_picker = ft.DatePicker(
        on_change=change_date,
        on_dismiss=date_picker_dismissed,
        first_date=datetime(2020, 1, 1),
        last_date=datetime.today(),
        help_text="Выберите дату"
    )

    date_button = ft.ElevatedButton(
        "Выберите число", width=200,
        icon=ft.icons.CALENDAR_MONTH,
        on_click=lambda _: date_picker.pick_date(),
    )

    p_reject = ft.Dropdown(
        width=200,
        options=[
            ft.dropdown.Option("Недостаточно баллов"),
            ft.dropdown.Option("Имеется наказания"),
            ft.dropdown.Option("Не подходит под критерии\n(Rep/Online/Баллы/Дни)"),
        ]
    )

    def route_change(e):
        if page.route == '/':
            page.views.clear()

            logged_in = page.client_storage.contains_key("loggedin")
            nickname = page.client_storage.get("nickname")
            current_position = get_current_position(nickname)

            if logged_in and nickname:
                buttons = [
                    ElevatedButton("Неактивы", icon="free_breakfast", icon_color="yellow",
                                   on_click=lambda _: page.go("/neaktiv")),
                    ElevatedButton("Повышения", icon="keyboard_double_arrow_up", icon_color='green',
                                   on_click=lambda _: page.go("/promotions")),
                ]

                if current_position in top_management:
                    buttons.append(
                        ElevatedButton("Передача имущества", icon="shopping_cart_sharp", icon_color="red",
                                       on_click=lambda _: page.go("/property_transfer"))
                    )

                page.views.append(
                    View(
                        "/",
                        [
                            AppBar(
                                center_title=True,
                                title=Text("Admin Dashboard"),
                                bgcolor=colors.SURFACE_VARIANT,
                                actions=[
                                    ft.IconButton(ft.icons.SUNNY, on_click=change_theme),
                                ]
                            ),
                            Column(buttons)

                        ]
                    )
                )

            else:
                page.go("/login")

        page.update()
        if page.route == '/neaktiv':
            logged_in = page.client_storage.contains_key("loggedin")
            nickname = page.client_storage.get("nickname")
            if logged_in and nickname:
                page.views.clear()
                current_position = get_current_position(nickname)
                if current_position in f_management:
                    department = 'Лидеры'
                if current_position in h_management:
                    department = 'АП'
                if current_position in top_management:
                    department = 'Администрация'
                else:
                    page.snack_bar = ft.SnackBar(ft.Text(f'😔 Ошибка,невозможно определить ваш отдел.'),
                                                 bgcolor=ft.colors.RED)
                    page.snack_bar.open = True
                    page.update()
                    page.go("/")
                    return

                server = get_server(nickname)

                grid_view2 = ft.GridView(
                    expand=True,
                    runs_count=5,
                    max_extent=200,
                    child_aspect_ratio=1.0,
                    spacing=3,
                    run_spacing=3,
                    auto_scroll=True,

                )
                status = 'В ожидании'
                cursor.execute("SELECT id,nickname FROM neaktiv WHERE department = %s AND server = %s AND status = %s",
                               (department, server, status,))
                neaktivs = cursor.fetchall()
                page.views.append(View(
                    "/neaktiv",
                    [
                        AppBar(leading=ft.IconButton(ft.icons.HOME, on_click=lambda _: page.go("/")), center_title=True,
                               title=Text("Неактивы пользователей"), bgcolor=colors.SURFACE_VARIANT,
                               actions=[ft.IconButton(ft.icons.SUNNY, on_click=change_theme)]),
                        grid_view2,

                    ]

                )),
                if not neaktivs:
                    no_neaktivs = ft.Text("Заявок на неактив нет.", text_align=ft.TextAlign.CENTER, color=colors.RED,
                                          weight=ft.FontWeight.BOLD, size=16)
                    grid_view2.controls.append(no_neaktivs)
                else:
                    for neaktiv in neaktivs:
                        id = neaktiv[0]
                        neaktiv = ft.TextButton(text=f"Заявка #{id}",
                                                on_click=(lambda i: lambda _: page.go(f"/neaktiv/{i}"))(id),
                                                style=ButtonStyle(shape=ft.RoundedRectangleBorder(radius=20), ),
                                                width=100)
                        grid_view2.controls.append(neaktiv)
            else:
                page.go("/login")
        page.update()

        if page.route.startswith("/neaktiv/"):
            logged_in = page.client_storage.contains_key("loggedin")
            nickname = page.client_storage.get("nickname")
            if logged_in and nickname:
                page.views.clear()
                id = page.route.split('/')[2]
                cursor.execute("SELECT status FROM neaktiv WHERE id = %s", (id,))
                status = cursor.fetchone()[0]
                if status == 'В ожидании':
                    cursor.execute("SELECT * FROM neaktiv WHERE id = %s", (id,))
                    n_info = cursor.fetchone()

                    page.views.append(View(
                        "/neaktiv",
                        [
                            AppBar(leading=ft.IconButton(ft.icons.ARROW_BACK_IOS_NEW,
                                                         on_click=lambda _: page.go("/neaktiv")), center_title=True,
                                   title=Text("Неактивы пользователей"), bgcolor=colors.SURFACE_VARIANT,
                                   actions=[ft.IconButton(ft.icons.SUNNY, on_click=change_theme)]),
                            ft.Row([]),
                            ft.Row([Text(f"Заявка на неактив #{id}", weight=ft.FontWeight.BOLD, size=16)],
                                   alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([Text(f"От: {n_info[2]}", size=16)], alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([Text(f"Даты неактива: {n_info[5]}", size=16)],
                                   alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([Text(f"Причина неактива: {n_info[8]}", size=16)],
                                   alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([ElevatedButton(text="Одобрить", icon="gpp_good_sharp", icon_color="green",
                                                   width=200, on_click=lambda e: neaktiv_handle(id, status='approve')),
                                    ElevatedButton(text="Отказать", icon="do_not_disturb_sharp", width=200,
                                                   icon_color="red",
                                                   on_click=lambda e: neaktiv_handle(id, status='reject'))],
                                   alignment=ft.MainAxisAlignment.CENTER),

                        ]
                    )),
                else:
                    page.snack_bar = ft.SnackBar(ft.Text(f'Заявка {id} уже рассмотрена!'), bgcolor=ft.colors.RED)
                    page.snack_bar.open = True
                    page.go("/neaktiv")
                    page.update()
            else:
                page.go("/login")
        page.update()

        if page.route == '/promotions':
            logged_in = page.client_storage.contains_key("loggedin")
            nickname = page.client_storage.contains_key("nickname")
            if logged_in and nickname:
                page.views.clear()
                current_position = get_current_position(nickname)
                server = get_server(nickname)

                grid_view2 = ft.GridView(
                    expand=True,
                    runs_count=5,
                    max_extent=200,
                    child_aspect_ratio=1.0,
                    spacing=3,
                    run_spacing=3,
                    auto_scroll=True,

                )
                status = 'В ожидании'
                cursor.execute("SELECT id,nickname FROM promotions WHERE server = %s AND status = %s",
                               (server, status,))
                promotions = cursor.fetchall()
                page.views.append(View(
                    "/promotions",
                    [
                        AppBar(leading=ft.IconButton(ft.icons.HOME, on_click=lambda _: page.go("/")), center_title=True,
                               title=Text("Заявки на повышения"), bgcolor=colors.SURFACE_VARIANT,
                               actions=[ft.IconButton(ft.icons.SUNNY, on_click=change_theme)]),
                        grid_view2,

                    ]

                )),
                if not promotions:
                    no_promotions = ft.Text("Заявок на повышения нет.", text_align=ft.TextAlign.CENTER,
                                            color=colors.RED, weight=ft.FontWeight.BOLD, size=16)
                    grid_view2.controls.append(no_promotions)
                else:
                    for promotion in promotions:
                        id = promotion[0]
                        p_button = ft.TextButton(text=f"Заявка #{id}",
                                                 on_click=(lambda i: lambda _: page.go(f"/promotions/{i}"))(id),
                                                 style=ButtonStyle(shape=ft.RoundedRectangleBorder(radius=20), ),
                                                 width=100)
                        grid_view2.controls.append(p_button)
            else:
                page.go("/login")
        page.update()

        if page.route.startswith("/promotions/"):
            logged_in = page.client_storage.contains_key("loggedin")
            nickname = page.client_storage.get("nickname")
            if logged_in and nickname:
                page.views.clear()
                id = page.route.split('/')[2]
                cursor.execute("SELECT status FROM promotions WHERE id = %s", (id,))
                status = cursor.fetchone()[0]
                if status == 'В ожидании':
                    cursor.execute("SELECT * FROM promotions WHERE id = %s", (id,))
                    p_info = cursor.fetchone()
                    img = ft.Image(
                        src=f"https://iili.io/Jc9hhV1.jpg",
                        semantics_label="Скриншот /astats",
                        width=500,
                        height=550,
                        fit=ft.ImageFit.COVER,
                    )
                    page.views.append(View(
                        "/promotions/",
                        [
                            AppBar(leading=ft.IconButton(ft.icons.ARROW_BACK_IOS_NEW,
                                                         on_click=lambda _: page.go("/promotions")), center_title=True,
                                   title=Text("Заявки на повышения"), bgcolor=colors.SURFACE_VARIANT,
                                   actions=[ft.IconButton(ft.icons.SUNNY, on_click=change_theme)]),
                            ft.Row([]),
                            ft.Row([Text(f"Заявка на повышения #{id}", weight=ft.FontWeight.BOLD, size=16)],
                                   alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([Text(f"От: {p_info[2]}", size=16)], alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([Text(f"Текущая должность: {p_info[4]}", size=16)],
                                   alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([Text(f"Желаемая должность: {p_info[5]}", size=16)],
                                   alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([Text(f"Время подачи: {p_info[7]}", size=16)],
                                   alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([ft.TextButton(f"Скриншот /astats",
                                                  on_click=lambda _: page.go(f"/promotions/{id}/p_image"))],
                                   alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([ElevatedButton(text="Одобрить", icon="gpp_good_sharp", icon_color="green",
                                                   width=200, on_click=lambda e: promotion_handle(id, status='approve',
                                                                                                  reason="Accepted")),
                                    ElevatedButton(text="Отказать", icon="do_not_disturb_sharp", width=200,
                                                   icon_color="red",
                                                   on_click=lambda e: promotion_handle(id, status='reject',
                                                                                       reason="reason_needed"))],
                                   alignment=ft.MainAxisAlignment.CENTER),

                        ]
                    )),
                else:
                    page.snack_bar = ft.SnackBar(ft.Text(f'Заявка {id} уже рассмотрена!'), bgcolor=ft.colors.RED)
                    page.snack_bar.open = True
                    page.go("/promotions")
                    page.update()
            else:
                page.go("/login")
        page.update()

        if page.route.endswith("/p_image"):
            logged_in = page.client_storage.contains_key("loggedin")
            nickname = page.client_storage.get("nickname")
            if logged_in and nickname:
                page.views.clear()
                id = page.route.split('/')[2]
                cursor.execute("SELECT file_id FROM promotions WHERE id = %s", (id,))
                d_img = cursor.fetchone()[0]
                img = ft.Image(
                    src=f"{d_img}",
                    semantics_label="Скриншот /astats",
                    width=350,
                    height=400,
                    fit=ft.ImageFit.COVER,
                )
                page.views.append(View(
                    "/p_image",
                    [
                        AppBar(leading=ft.IconButton(ft.icons.ARROW_BACK_IOS_NEW,
                                                     on_click=lambda _: page.go(f"/promotions/{id}")),
                               center_title=True, title=Text("Заявки на повышения"), bgcolor=colors.SURFACE_VARIANT,
                               actions=[ft.IconButton(ft.icons.SUNNY, on_click=change_theme)]),
                        ft.Row([]),
                        ft.Row([img]),
                    ]
                )),

            else:
                page.go("/login")

        if page.route.endswith("/p_reject"):
            logged_in = page.client_storage.contains_key("loggedin")
            nickname = page.client_storage.get("nickname")
            if logged_in and nickname:
                id = page.route.split('/')[2]
                cursor.execute("SELECT status FROM promotions WHERE id = %s", (id,))
                status = cursor.fetchone()[0]
                if status == 'В ожидании':
                    page.views.clear()
                    page.views.append(View(
                        "/p_reject",
                        [
                            AppBar(leading=ft.IconButton(ft.icons.ARROW_BACK_IOS_NEW,
                                                         on_click=lambda _: page.go(f"/promotions/{id}")),
                                   center_title=True, title=Text("Выбор причины для отказа:"),
                                   bgcolor=colors.SURFACE_VARIANT,
                                   actions=[ft.IconButton(ft.icons.SUNNY, on_click=change_theme)]),
                            ft.Row([]),
                            ft.Row([]),
                            ft.Row([p_reject], alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([]),
                            ft.Row([ElevatedButton(text="Отказать", icon="do_not_disturb_sharp", width=200,
                                                   icon_color="red",
                                                   on_click=lambda e: promotion_handle(id, status='reason',
                                                                                       reason=p_reject.value))],
                                   alignment=ft.MainAxisAlignment.CENTER),

                        ]

                    )),
                else:
                    page.snack_bar = ft.SnackBar(ft.Text(f'Заявка {id} уже рассмотрена!'), bgcolor=ft.colors.RED)
                    page.snack_bar.open = True
                    page.go("/promotions")
                    page.update()
            else:
                page.go("/login")
        page.update()

        if page.route == '/property_transfer':
            logged_in = page.client_storage.contains_key("loggedin")
            nickname = page.client_storage.get("nickname")
            if logged_in and nickname:
                page.views.clear()
                current_position = get_current_position(nickname)
                server = get_server(nickname)

                grid_view2 = ft.GridView(
                    expand=True,
                    runs_count=5,
                    max_extent=200,
                    child_aspect_ratio=1.0,
                    spacing=3,
                    run_spacing=3,
                    auto_scroll=True,

                )
                status = 'В ожидании'
                cursor.execute("SELECT id,nickname FROM property_transfer WHERE server = %s AND status = %s",
                               (server, status,))
                p_t = cursor.fetchall()
                page.views.append(View(
                    "/promotions",
                    [
                        AppBar(leading=ft.IconButton(ft.icons.HOME, on_click=lambda _: page.go("/")), center_title=True,
                               title=Text("Заявки на передачу имущества"), bgcolor=colors.SURFACE_VARIANT,
                               actions=[ft.IconButton(ft.icons.SUNNY, on_click=change_theme)]),
                        grid_view2,

                    ]

                )),
                if not p_t:
                    no_p_t = ft.Text("Заявок на передачу имущества нет.", text_align=ft.TextAlign.CENTER,
                                     color=colors.RED, weight=ft.FontWeight.BOLD, size=16)
                    grid_view2.controls.append(no_p_t)
                else:
                    for pt in p_t:
                        id = pt[0]
                        pt_button = ft.TextButton(text=f"Заявка #{id}",
                                                  on_click=(lambda i: lambda _: page.go(f"/property_transfer/{i}"))(id),
                                                  style=ButtonStyle(shape=ft.RoundedRectangleBorder(radius=20), ),
                                                  width=100)
                        grid_view2.controls.append(pt_button)
            else:
                page.go("/login")
        page.update()

        if page.route.startswith("/property_transfer/"):
            logged_in = page.client_storage.contains_key("loggedin")
            nickname = page.client_storage.get("nickname")
            if logged_in and nickname:
                page.views.clear()
                id = page.route.split('/')[2]
                cursor.execute("SELECT status FROM property_transfer WHERE id = %s", (id,))
                status = cursor.fetchone()[0]
                if status == 'В ожидании':
                    cursor.execute("SELECT * FROM property_transfer WHERE id = %s", (id,))
                    pt_info = cursor.fetchone()
                    img = ft.Image(
                        src=f"https://iili.io/Jc9hhV1.jpg",
                        semantics_label="Скриншот /astats",
                        width=500,
                        height=550,
                        fit=ft.ImageFit.COVER,
                    )
                    page.views.append(View(
                        "/property_transfer",
                        [
                            AppBar(leading=ft.IconButton(ft.icons.ARROW_BACK_IOS_NEW,
                                                         on_click=lambda _: page.go("/property_transfer")),
                                   center_title=True, title=Text("Заявки на передачу имущества"),
                                   bgcolor=colors.SURFACE_VARIANT,
                                   actions=[ft.IconButton(ft.icons.SUNNY, on_click=change_theme)]),
                            ft.Row([]),
                            ft.Row([Text(f"Заявка на передачу #{id}", weight=ft.FontWeight.BOLD, size=16)],
                                   alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([Text(f"От: {pt_info[2]}", size=16)], alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([Text(f"Проводит транзакцию с: {pt_info[4]}", size=16)],
                                   alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([Text(f"Информация о транзакции:\n{pt_info[5]}", size=16)],
                                   alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([Text(f"Госс.стоимость предмета: {pt_info[6]}", size=16)],
                                   alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([Text(f"Долг: {pt_info[7]}", size=16)], alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([Text(f"Дата возрата долга: {pt_info[8]}", size=16)],
                                   alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([ElevatedButton(text="Одобрить", icon="gpp_good_sharp", icon_color="green",
                                                   width=200,
                                                   on_click=lambda e: property_transfer_handle(id, status='approve')),
                                    ElevatedButton(text="Отказать", icon="do_not_disturb_sharp", width=200,
                                                   icon_color="red",
                                                   on_click=lambda e: property_transfer_handle(id, status='reject'))],
                                   alignment=ft.MainAxisAlignment.CENTER),

                        ]
                    )),
                else:
                    page.snack_bar = ft.SnackBar(ft.Text(f'Заявка {id} уже рассмотрена!'), bgcolor=ft.colors.RED)
                    page.snack_bar.open = True
                    page.go("/property_transfer")
                    page.update()
            else:
                page.go("/login")
        page.update()

        if page.route == '/login':
            logged_in = page.client_storage.contains_key("loggedin")
            if not logged_in:
                page.views.clear()
                page.views.append(
                    View("/login", [
                        AppBar(
                            center_title=True,
                            title=ft.Text("Вход в панель управления"),
                            bgcolor=colors.SURFACE_VARIANT,
                            actions=[
                                ft.IconButton(ft.icons.SUNNY, on_click=change_theme),
                            ],
                        ),
                        ft.Row([
                            ft.Column(
                                [
                                    user_login,
                                    user_pass,
                                    btn_auth,

                                ],
                            )
                        ], alignment=ft.MainAxisAlignment.CENTER,
                        ),

                    ],
                         ),
                )
            else:
                page.go("/")

        page.update()
        if page.route == "/users":
            logged_in = page.client_storage.contains_key("loggedin")
            username = page.client_storage.get("nickname")
            if logged_in and username:
                username = page.client_storage.get("nickname")
                cursor.execute("SELECT server FROM users WHERE nickname = %s", (username,))
                result = cursor.fetchone()
                server = result[0]
                page.views.clear()
                cursor.execute("SELECT nickname FROM users WHERE server = %s", (server,))
                result2 = cursor.fetchall()
                users = []
                for user in result2:
                    users.append(user[0])
                # cursor.close()
                # conn.close()
                grid_view = ft.GridView(
                    expand=True,
                    runs_count=5,
                    max_extent=200,
                    child_aspect_ratio=1.0,
                    spacing=3,
                    run_spacing=3,
                    auto_scroll=True

                )

                page.views.append(
                    ft.View("/users", [
                        ft.AppBar(
                            leading=ft.IconButton(ft.icons.HOME, on_click=lambda _: page.go("/")),
                            title=ft.Text("Все пользователи"),
                            bgcolor=ft.colors.SURFACE_VARIANT,
                            actions=[
                                ft.IconButton(ft.icons.SUNNY, on_click=change_theme),

                            ],
                        ),

                        grid_view,

                    ])
                )

                for user in users:
                    btn = ft.TextButton(text=user, width=200, height=50, icon="person",
                                        on_click=lambda e, user=user: go_to_user(user)(e))
                    grid_view.controls.append(btn)
            else:
                page.go("/login")
        page.update()

        if page.route.startswith("/users/"):
            logged_in = page.client_storage.contains_key("loggedin")
            nickname = page.client_storage.get("nickname")
            if logged_in and nickname:
                page.views.clear()
                username = page.route.split("/users/")[1]
                # send_message_tg(user_id, username)
                page.views.append(
                    View(
                        "/users/",
                        [
                            AppBar(
                                leading=ft.IconButton(ft.icons.HOME, on_click=lambda _: page.go("/")),
                                center_title=True,
                                title=Text(f"{username}"), bgcolor=colors.SURFACE_VARIANT,
                                actions=[
                                    ft.IconButton(ft.icons.SUNNY, on_click=change_theme),
                                ],
                            ),
                            # ElevatedButton("Перейти обратно к списку", on_click=lambda _: page.go("/users")),
                            # ft.Row([ft.Text(f"Nickname: {username}",weight=ft.FontWeight.BOLD,size=24),],
                            # alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([]),

                            ft.Row([ElevatedButton(text="Изменить информацию о пользователе",
                                                   on_click=lambda _: page.go(f"/{username}/change_info")), ],
                                   alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([ElevatedButton(text="Выдача наказаний",
                                                   on_click=lambda _: page.go(f"/{username}/punishment")), ],
                                   alignment=ft.MainAxisAlignment.CENTER),
                            ft.Row([]),
                            ft.Row([ElevatedButton(text="Снять пользователя",
                                                   on_click=lambda _: page.go(f"/{username}/delete")), ],
                                   alignment=ft.MainAxisAlignment.CENTER)

                        ],
                    )
                )
            else:
                page.go("/login")

        page.update()

        if page.route.endswith("/delete"):
            logged_in = page.client_storage.contains_key("loggedin")
            nickname = page.client_storage.get("nickname")
            if logged_in and nickname:
                page.views.clear()
                path_parts = page.route.split("/")
                username = path_parts[1]
                page.views.append(View(f"/{username}/delete", [AppBar(leading=ft.IconButton(ft.icons.ARROW_BACK_IOS_NEW,
                                                                                            on_click=lambda _: page.go(
                                                                                                f"/users/{username}")),
                                                                      center_title=True,
                                                                      title=Text(f"Снятия пользователя"),
                                                                      bgcolor=colors.SURFACE_VARIANT, actions=[
                        ft.IconButton(ft.icons.SUNNY, on_click=change_theme), ]),
                                                               ft.Row([]),
                                                               ft.Row(
                                                                   [ft.Column([delete_type_field, delete_type_button])],
                                                                   alignment=ft.MainAxisAlignment.CENTER)]))

            else:
                page.go("/login")
        page.update()
        if page.route.endswith("/punishment"):
            logged_in = page.client_storage.contains_key("loggedin")
            nickname = page.client_storage.get("nickname")
            if logged_in and nickname:
                page.views.clear()
                path_parts = page.route.split("/")
                username = path_parts[1]
                page.views.append(View(f"/{username}/punishment", [AppBar(
                    leading=ft.IconButton(ft.icons.ARROW_BACK_IOS_NEW,
                                          on_click=lambda _: page.go(f"/users/{username}")), center_title=True,
                    title=Text(f"Наказания"), bgcolor=colors.SURFACE_VARIANT,
                    actions=[ft.IconButton(ft.icons.SUNNY, on_click=change_theme), ]),
                                                                   ft.Row([]),
                                                                   ft.Row(
                                                                       [
                                                                           ft.ElevatedButton(text="Выговор",
                                                                                             on_click=lambda _: page.go(
                                                                                                 f"{username}/punishment/vig")),
                                                                           ft.ElevatedButton(text="Предупреждение",
                                                                                             on_click=lambda _: page.go(
                                                                                                 f"{username}/punishment/pred"))
                                                                       ],
                                                                       alignment=ft.MainAxisAlignment.CENTER
                                                                   ),

                                                                   ft.Row([ElevatedButton(text="Устник",
                                                                                          on_click=lambda _: page.go(
                                                                                              f"{username}/punishment/ustnik"))],
                                                                          alignment=ft.MainAxisAlignment.CENTER)]))
            else:
                page.go("/login")
        page.update()
        if "/punishment/" in page.route:
            logged_in = page.client_storage.contains_key("loggedin")
            nickname = page.client_storage.get("nickname")
            if logged_in and nickname:
                buttons = [
                    IconButton(ft.icons.PLUS_ONE_SHARP, on_click=lambda _: page.go("/neaktiv")),
                    IconButton(ft.icons.EXPOSURE_MINUS_1_SHARP, on_click=lambda _: page.go("/promotions"))
                ],
                page.views.clear()
                path_parts = page.route.split("/")
                username = path_parts[0]
                punish_type = path_parts[2]
                cursor.execute(f"SELECT {punish_type} FROM users WHERE nickname = %s", (username,))
                res = cursor.fetchone()
                if res:
                    current_value = res[0]
                else:
                    current_value = 'Неизвестно'
                page.views.append(View(f"/{username}/punishement/{punish_type}", [AppBar(
                    leading=IconButton(ft.icons.ARROW_BACK_IOS_NEW,
                                       on_click=lambda _: page.go(f"/{username}/punishment")), center_title=True,
                    title=Text(f"Выдача наказания"), bgcolor=colors.SURFACE_VARIANT,
                    actions=[IconButton(ft.icons.SUNNY, on_click=change_theme), ]),
                                                                                  # ft.Row([ft.Text(f"Текущие значение: {current_value}")],alignment=ft.MainAxisAlignment.CENTER),
                                                                                  ft.Row(
                                                                                      [
                                                                                          ft.IconButton(ft.icons.REMOVE,
                                                                                                        on_click=minus_click),
                                                                                          punish_data_field,
                                                                                          ft.IconButton(ft.icons.ADD,
                                                                                                        on_click=plus_click),
                                                                                      ],
                                                                                      alignment=ft.MainAxisAlignment.CENTER,
                                                                                  ),
                                                                                  ft.Row([punish_data_field2, ],
                                                                                         alignment=ft.MainAxisAlignment.CENTER),
                                                                                  ft.Row([punish_data_btn],
                                                                                         alignment=ft.MainAxisAlignment.CENTER)
                                                                                  ]))
                # ft.Row([ft.Column([punish_data_field,punish_data_btn])],alignment=ft.MainAxisAlignment.CENTER)
            else:
                page.go("/login")
        page.update()
        if page.route.endswith("/change_info"):
            logged_in = page.client_storage.contains_key("loggedin")
            nickname = page.client_storage.get("nickname")
            if logged_in and nickname:
                page.views.clear()
                path_parts = page.route.split("/")
                username = path_parts[1]
                page.views.append(View(f"/{username}/change_info", [AppBar(
                    leading=ft.IconButton(ft.icons.ARROW_BACK_IOS_NEW,
                                          on_click=lambda _: page.go(f"/users/{username}")), center_title=True,
                    title=Text(f"Управление информацией пользователя."), bgcolor=colors.SURFACE_VARIANT,
                    actions=[ft.IconButton(ft.icons.SUNNY, on_click=change_theme), ]),
                                                                    ft.Row([]),
                                                                    ft.Row([ElevatedButton(text="Изменить возраст",
                                                                                           on_click=lambda _: page.go(
                                                                                               f"/{username}/change_info/age"))],
                                                                           alignment=ft.MainAxisAlignment.CENTER),
                                                                    ft.Row([]),
                                                                    ft.Row([ElevatedButton(text="Изменить Nickname",
                                                                                           on_click=lambda _: page.go(
                                                                                               f"/{username}/change_info/nickname"))],
                                                                           alignment=ft.MainAxisAlignment.CENTER),
                                                                    ft.Row([]),
                                                                    ft.Row([ElevatedButton(text="Изменить Report",
                                                                                           on_click=lambda _: page.go(
                                                                                               f"/{username}/change_info/rep"))],
                                                                           alignment=ft.MainAxisAlignment.CENTER),
                                                                    ft.Row([]),
                                                                    ft.Row([ElevatedButton(text="Изменить Online",
                                                                                           on_click=lambda _: page.go(
                                                                                               f"/{username}/change_info/online"))],
                                                                           alignment=ft.MainAxisAlignment.CENTER),
                                                                    ft.Row([]),
                                                                    ft.Row([ElevatedButton(text="Изменить Баллы",
                                                                                           on_click=lambda _: page.go(
                                                                                               f"/{username}/change_info/online"))],
                                                                           alignment=ft.MainAxisAlignment.CENTER),
                                                                    ft.Row([]),
                                                                    ft.Row([ElevatedButton(
                                                                        text="Изменить дату постановления",
                                                                        on_click=lambda _: page.go(
                                                                            f"/{username}/change_info/created_at"))],
                                                                           alignment=ft.MainAxisAlignment.CENTER),
                                                                    ]))

            else:
                page.go("/login")

        page.update()

        if "/change_info/" in page.route:
            logged_in = page.client_storage.contains_key("loggedin")
            nickname = page.client_storage.get("nickname")
            if logged_in and nickname:
                page.views.clear()
                path_parts = page.route.split("/")
                username = path_parts[1]
                info_type = path_parts[3]
                cursor.execute(f"SELECT {info_type} FROM users WHERE nickname = %s", (username,))
                res = cursor.fetchone()
                if res:
                    current_value = res[0]
                else:
                    current_value = 'Неизвестно'
                page.views.append(View(f"/{username}/change_info/age", [AppBar(
                    leading=IconButton(ft.icons.ARROW_BACK_IOS_NEW,
                                       on_click=lambda _: page.go(f"/{username}/change_info")), center_title=True,
                    title=Text(f"Управление информацией пользователя."), bgcolor=colors.SURFACE_VARIANT,
                    actions=[IconButton(ft.icons.SUNNY, on_click=change_theme), ]),
                                                                        ft.Row([ft.Text(
                                                                            f"Текущие значение: {current_value}")],
                                                                               alignment=ft.MainAxisAlignment.CENTER),
                                                                        ft.Row([]),
                                                                        ft.Row([ft.Column(
                                                                            [data_type_field, data_field_btn])],
                                                                               alignment=ft.MainAxisAlignment.CENTER)]))
            else:
                page.go("/login")
        page.update()
        if page.route.endswith("/change_info/created_at"):
            logged_in = page.client_storage.contains_key("loggedin")
            nickname = page.client_storage.get("nickname")
            if logged_in and nickname:
                page.views.clear()
                path_parts = page.route.split("/")
                username = path_parts[1]
                info_type = path_parts[-1]
                page.views.append(View(f"/{username}/change_info/created_at", [AppBar(
                    leading=IconButton(ft.icons.ARROW_BACK_IOS_NEW,
                                       on_click=lambda _: page.go(f"/{username}/change_info")), center_title=True,
                    title=Text(f"Управление информацией пользователя."), bgcolor=colors.SURFACE_VARIANT,
                    actions=[IconButton(ft.icons.SUNNY, on_click=change_theme), ]),
                                                                               ft.Row([]),
                                                                               ft.Row([]),
                                                                               ft.Row([ft.Column(
                                                                                   [date_picker, date_button])],
                                                                                      alignment=ft.MainAxisAlignment.CENTER)]))
            else:
                page.go("/login")
        page.update()

    def view_pop(e):
        page.views.pop()
        top_view = page.views[-1]
        page.go(top_view.route)

    page.on_route_change = route_change
    page.on_view_pop = view_pop

    page.go(page.route)


ft.app(target=main, assets_dir="assets", view=ft.AppView.WEB_BROWSER)
# ft.app(target=main, view=ft.AppView.WEB_BROWSER,assets_dir="./app/assets")
