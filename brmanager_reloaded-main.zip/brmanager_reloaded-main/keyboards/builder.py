from aiogram import Bot
from aiogram.types import InlineKeyboardButton,InlineKeyboardMarkup,ReplyKeyboardMarkup,KeyboardButton,WebAppInfo
from aiogram.utils.keyboard import InlineKeyboardBuilder,ReplyKeyboardBuilder
from aiogram.filters.callback_data import CallbackData

from data.positions import *
from data.flet_url import url as f_url

def cancel_button():
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="Отменить процесс",callback_data="cancel_process"))
    
    return builder.as_markup()

def start_buttons(current_position):
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📊 Моя статистика",callback_data="my_stats"),
        InlineKeyboardButton(text="📝 Подача заявлений",callback_data="requests"),
        width=1
    )
    if current_position in top_management + f_management +h_management:
        builder.row(InlineKeyboardButton(text="🔴 Панель Управления",callback_data="admin_panel"))
    
    
    return builder.as_markup()

def requests_panel(department):
    builder = InlineKeyboardBuilder()

    builder.row(
        InlineKeyboardButton(text="Неактив",callback_data="neaktiv"))
    
    if department == 'Администрация':
        builder.row(
            InlineKeyboardButton(text="Повышение",callback_data="promotion"),
            InlineKeyboardButton(text="Передача имущества",callback_data="property_transfer"),
            InlineKeyboardButton(text="Доп.активность",callback_data="extra_work"),
        )

    if department == 'Лидеры':
        builder.row(InlineKeyboardButton(text="Доп.активность",callback_data="extra_work"))

    builder.row(InlineKeyboardButton(text="На главную",callback_data="main_menu"))
    return builder.as_markup()
def admin_panel(current_position):
    builder = InlineKeyboardBuilder()
    if current_position in top_management + f_management +h_management:
        builder.row(InlineKeyboardButton(text="Панель Управления(App)",web_app=WebAppInfo(url=f_url)))
    if current_position in top_management:
        builder.row(InlineKeyboardButton(text="Администрация",callback_data="admins_menu"))
    if current_position in top_management + h_management:
        builder.row(InlineKeyboardButton(text="АП",callback_data="helpers_menu"))
    if current_position in top_management + f_management:
        builder.row(InlineKeyboardButton(text="Лидеры",callback_data="leaders_menu"))
    if current_position in top_management:
        builder.row(InlineKeyboardButton(text="Обновить SessionID",callback_data="sessionid"))
    builder.row(InlineKeyboardButton(text=" ➕ Добавить пользователя",callback_data="add_user"))
    builder.row(InlineKeyboardButton(text="На главную",callback_data="main_menu"))
    return builder.as_markup()


def select_position(current_position):
    builder = ReplyKeyboardBuilder()
    if current_position in top_management:
        builder.button(text="Младший Модератор")
    elif current_position in goss_management:
        builder.row(KeyboardButton(text="Лидер Право"))
        builder.button(text="Лидер ФСБ")
        builder.button(text="Лидер УМВД")
        builder.row(KeyboardButton(text="Лидер ГИБДД"))
        builder.button(text="Лидер ВЧ")
        builder.button(text="Лидер ФСИН")
        builder.row(KeyboardButton(text="Лидер ЦБ"))
        builder.button(text="Лидер СМИ")
    elif current_position in opg_management:
        builder.row(KeyboardButton(text="Лидер А-ОПГ"))
        builder.button(text="Лидер Б-ОПГ")
        builder.row(KeyboardButton(text="Лидер Л-ОПГ"))
    elif current_position in h_management:
        builder.button(text="Агент Поддержки")
        
    return builder.as_markup(one_time_keyboard=True,resize_keyboard=True)
        
def neaktiv_markup():
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="Отдохнуть"))
    builder.button(text="Учеба")
    builder.button(text="Не успеваю")
    builder.row(KeyboardButton(text="Семейные обстоятельства"))
    builder.button(text="Проблемы с интернетом")

    return builder.as_markup(one_time_keyboard=True,resize_keyboard=True)

def admins_menu(current_position):
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="Пользователи",callback_data='users_admin'),   
    )
    if current_position == 'Главный Администратор':
        builder.row(InlineKeyboardButton(text="Привязать таблицу",callback_data="link_table_admin"))
    
    builder.row(InlineKeyboardButton(text="На главную",callback_data="main_menu"))

    return builder.as_markup()

def helpers_menu(current_position):
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="Пользователи",callback_data='users_helper'))
    
    if current_position == 'Главный Администратор':
        builder.row(InlineKeyboardButton(text="Привязать таблицу",callback_data="link_table_helper"))
    
    builder.row(InlineKeyboardButton(text="На главную",callback_data="main_menu"))

    return builder.as_markup()
def leaders_menu(current_position):
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="Пользователи",callback_data='users_leader'))
    
    if current_position == 'Главный Администратор':
        builder.row(InlineKeyboardButton(text="Привязать таблицу",callback_data="link_table_leader"))
    
    builder.row(InlineKeyboardButton(text="На главную",callback_data="main_menu"))

    return builder.as_markup()

def select_chat():
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="Административный",callback_data="chat_admin_id"))
    builder.row(InlineKeyboardButton(text="Хэлперский",callback_data="chat_helper_id"))
    builder.row(InlineKeyboardButton(text="Лидерский",callback_data="chat_leader_id"))

    return builder.as_markup()

def stats_markup(user):
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="Панель управления пользователем",web_app=WebAppInfo(url=f"https://admdash.fly.dev/users/{user}")))

    return builder.as_markup()

def my_stats_choice():
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="Статистика(BOT)",callback_data="stats_bot"))
    builder.row(InlineKeyboardButton(text="Статистика(Game)",callback_data="stats_game"))
    builder.row(InlineKeyboardButton(text="На главную",callback_data="main_menu"))

    return builder.as_markup()

def select_day():
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="Сегодня",callback_data="stats_game_0"))
    builder.row(InlineKeyboardButton(text="Вчера",callback_data="stats_game_1"))
    builder.row(InlineKeyboardButton(text="2 дня назад",callback_data="stats_game_2"))
    builder.row(InlineKeyboardButton(text="3 дня назад",callback_data="stats_game_3"))
    builder.row(InlineKeyboardButton(text="4 дня назад",callback_data="stats_game_4"))
    builder.row(InlineKeyboardButton(text="5 дней назад",callback_data="stats_game_5"))
    builder.row(InlineKeyboardButton(text="6 дней назад",callback_data="stats_game_6"))
    builder.row(InlineKeyboardButton(text="7 дней назад",callback_data="stats_game_7"))
    builder.row(InlineKeyboardButton(text="За неделю",callback_data="stats_game_week"))
    builder.row(InlineKeyboardButton(text="За месяц",callback_data="stats_game_month"))
    builder.row(InlineKeyboardButton(text="На главную",callback_data="main_menu"))
    
    return builder.as_markup()

def select_day_gstats(user_id):
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="Сегодня",callback_data=f"gstats_game_0_{user_id}"))
    builder.row(InlineKeyboardButton(text="Вчера",callback_data=f"gstats_game_1_{user_id}"))
    builder.row(InlineKeyboardButton(text="2 дня назад",callback_data=f"gstats_game_2_{user_id}"))
    builder.row(InlineKeyboardButton(text="3 дня назад",callback_data=f"gstats_game_3_{user_id}"))
    builder.row(InlineKeyboardButton(text="4 дня назад",callback_data=f"gstats_game_4_{user_id}"))
    builder.row(InlineKeyboardButton(text="5 дней назад",callback_data=f"gstats_game_5_{user_id}"))
    builder.row(InlineKeyboardButton(text="6 дней назад",callback_data=f"gstats_game_6_{user_id}"))
    builder.row(InlineKeyboardButton(text="7 дней назад",callback_data=f"gstats_game_7_{user_id}"))
    builder.row(InlineKeyboardButton(text="За неделю",callback_data=f"gstats_game_week_{user_id}"))
    builder.row(InlineKeyboardButton(text="За месяц",callback_data=f"gstats_game_month_{user_id}"))
    builder.row(InlineKeyboardButton(text="На главную",callback_data="main_menu"))
    
    return builder.as_markup()

def neaktiv_manage():
    builder = InlineKeyboardBuilder()

    builder.row(InlineKeyboardButton(text="Управление неактивом",callback_data="manage_neaktiv"))
    
    return builder.as_markup()

def cancel_neaktiv():
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="Отменить неактив",callback_data="cancel_neaktiv"))
    builder.row(InlineKeyboardButton(text="Отменить процесс",callback_data="cancel_process"))

    return builder.as_markup()

def promotion_markup(position):
    builder = ReplyKeyboardBuilder()
    if position == 'Младший Модератор':
        builder.row(KeyboardButton(text="Модератор"))
    elif position == 'Модератор':
        builder.row(KeyboardButton(text="Ст.Модератор"))
    elif position == 'Ст.Модератор':
        builder.row(KeyboardButton(text="Администратор"))
    elif position.startswith("Следящий за"):
        role = position[11:].strip()
        #role = role.strip()
        builder.row(KeyboardButton(text=f"Ст.Следящий за {role}"))
    elif position.startswith("Ст.Следящий за") or position == 'Администратор':
        builder.row(KeyboardButton(text=f"Повышения недоступно!"))
    else:
        builder.row(KeyboardButton(text=f"Повышения недоступно!"))

    return builder.as_markup(one_time_keyboard=True,resize_keyboard=True)

def extra_work_markup(screens_link,r_id):
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="Одобрить",callback_data=f"extra_work_accept_{r_id}"),
        InlineKeyboardButton(text="Отказать",callback_data=f"extra_work_reject_{r_id}"),
    )
    builder.row(InlineKeyboardButton(text="Просмотреть скриншоты",url=screens_link))

    return builder.as_markup()

def extra_work_edit(id):
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="+3",callback_data=f"ex_work_3_{id}"),
        InlineKeyboardButton(text="+5",callback_data=f"ex_work_5_{id}"),
    )

    builder.row(InlineKeyboardButton(text="Назад",callback_data=f"back_to_extra_work_{id}"))

    return builder.as_markup()