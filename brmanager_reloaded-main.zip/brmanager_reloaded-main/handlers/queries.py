import mysql.connector
from data.sql_config import mysql_config
import requests
#import supabase

conn = mysql.connector.connect(**mysql_config)
cursor = conn.cursor()
conn.autocommit = True 


async def user_exists(user_id):
    cursor.execute("SELECT COUNT(*) FROM users WHERE user_id = %s", (user_id,))
    count = cursor.fetchone()[0]
    return count > 0

async def get_current_position(user_id):
    cursor.execute("SELECT current_position FROM users WHERE user_id = %s",(user_id,))
    result = cursor.fetchone()

    if result:
        return result[0]
    

async def get_nickname(user_id):
    cursor.execute("SELECT nickname FROM users WHERE user_id = %s",(user_id,))
    result = cursor.fetchone()

    if result:
        return result[0]
    
async def get_user_server(user_id):
    cursor.execute("SELECT server FROM users WHERE user_id = %s",(user_id,))
    result = cursor.fetchone()

    if result:
        return result[0]
    
async def get_user_server_nick(nickname):
    cursor.execute("SELECT server FROM users WHERE nickname = %s",(nickname,))
    result = cursor.fetchone()

    if result:
        return result[0]
    
async def get_user_department(user_id):
    cursor.execute("SELECT department FROM users WHERE user_id = %s",(user_id,))
    result = cursor.fetchone()

    if result:
        return result[0]
    
async def get_user_department_nick(nickname):
    cursor.execute("SELECT department FROM users WHERE nickname = %s",(nickname,))
    result = cursor.fetchone()

    if result:
        return result[0]

async def add_user_to_db(user_id,nickname,created_at,created_by,position,server,department):
    insert_query = "INSERT INTO users (user_id, nickname, created_at, created_by, current_position, server, department) VALUES (%s, %s, %s, %s, %s, %s, %s)"
    data = (user_id, nickname, created_at, created_by, position, server, department)
    cursor.execute(insert_query, data)
    conn.commit()


async def get_user_stats(nickname,server):
    cursor.execute("SELECT * FROM users WHERE nickname = %s AND server = %s",(nickname,server,))
    result = cursor.fetchone()

    if result:
        return result
    
async def get_admin_access(user_id):
    cursor.execute("SELECT admin_access FROM users WHERE user_id = %s",(user_id,))
    result = cursor.fetchone()

    if result:
        return result[0]
    
async def update_password(password,user_id):
    cursor.execute("UPDATE users SET admin_pass = %s WHERE user_id = %s",(password,user_id,))
    conn.commit()

async def update_chat_id(chat_id,chat_full_name,server):
    cursor.execute(f"UPDATE server_info SET {chat_full_name} = %s WHERE server = %s",(chat_id,server,))
    conn.commit()

async def get_management_chat(department,server):
    cursor.execute(f"SELECT chat_{department}_id FROM server_info WHERE server = %s",(server,))
    result = cursor.fetchone()

    if result:
        return result[0]

async def add_table_info(table_type,table_info,server):
    if table_type == 'admin':
        column = "admin_table"
    elif table_type == 'helper':
        column = "helper_table"
    else:
        column = "leader_table"


    cursor.execute(f"UPDATE server_info SET {column} = %s WHERE server = %s",(table_info,server,))
    conn.commit()

async def get_sessiond(server):
    cursor.execute("SELECT session_id FROM server_info WHERE server = %s",(server,))
    result = cursor.fetchone()

    if result:
        return result[0]
    
async def update_sessionid_db(sessionid,server):
    cursor.execute("UPDATE server_info SET session_id = %s WHERE server = %s",(sessionid,server))
    conn.commit()

async def neaktiv_insert(user_id,nickname,time,reason,department,server,month,num_days):
    cursor.execute("INSERT INTO neaktiv (user_id,nickname,department,server,time,month,num_days,reason,status) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)",(user_id,nickname,department,server,time,month,num_days,reason,'В ожидании'))
    conn.commit()

async def get_user_neaktiv(user_id):
    cursor.execute("SELECT * FROM neaktiv WHERE user_id = %s AND status = %s AND id = (SELECT MAX(id) FROM neaktiv WHERE user_id = %s AND status = %s)", (user_id, 'Одобрено', user_id, 'Одобрено'))
    result = cursor.fetchone()

    if result:
        return result
    
async def get_user_neaktiv_info(user_id,current_month):
    cursor.execute("SELECT COUNT(*) FROM neaktiv WHERE user_id = %s AND month = %s AND status = %s", (user_id, current_month, 'Одобрено'))
    result = cursor.fetchone()
    if result:
        return result[0]

async def get_neaktiv_days(user_id):
    cursor.execute("SELECT SUM(num_days) FROM neaktiv WHERE user_id = %s", (user_id,))
    result = cursor.fetchone()[0]

    if result:
        return result
    
async def get_table_link(server,department):
    cursor.execute(f"SELECT {department}_table FROM server_info WHERE server = %s",(server,))
    result = cursor.fetchone()[0]
    
    if result:
        return result

async def update_neaktiv(new_time_combined,id):
    cursor.execute("UPDATE neaktiv SET time = %s WHERE id = %s",(new_time_combined,id,))
    conn.commit()

async def promotion_insert(user_id,nickname,server,current_position,desired_position,file_id,timestamp):
    cursor.execute("INSERT INTO promotions (user_id,nickname,server,current_position,desired_position,file_id,timestamp,status) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",(user_id,nickname,server,current_position,desired_position,file_id,timestamp,'В ожидании'))
    conn.commit()

async def property_transfer_insert(user_id,adm_nick,server,p_nickname,info,goss_price,dolg,dolg_date,timestamp):
    cursor.execute("INSERT INTO property_transfer(user_id, nickname, server, p_nickname, info, goss_price, dolg, dolg_date, timestamp) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (user_id, adm_nick, server, p_nickname, info, goss_price, dolg, dolg_date, timestamp))

    conn.commit()                

async def get_user_id(nickname):
    cursor.execute("SELECT user_id FROM users WHERE nickname = %s ",(nickname,))
    result = cursor.fetchone()[0]

    if result:
        return result

async def extra_work_insert(user_id,nickname,server,department_db,info,screens_link,time):
    cursor.execute("INSERT INTO extra_work (user_id,nickname,server,department,info,screens_link,timestamp) VALUES(%s,%s,%s,%s,%s,%s,%s)",(user_id,nickname,server,department_db,info,screens_link,time))
    conn.commit()