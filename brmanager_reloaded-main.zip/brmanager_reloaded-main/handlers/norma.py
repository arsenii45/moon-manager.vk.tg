async def check_norma():
    print("Check norma")