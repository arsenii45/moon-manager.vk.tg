from dotenv import load_dotenv
load_dotenv()

import os
from datetime import datetime
import pytz
from supabase import create_client
import asyncio
import gspread

url = os.environ.get("SUPABASE_URL")
key = os.environ.get("SUPABASE_KEY")

supabase = create_client (url, key)


async def user_exists(user_id):
    request = supabase.table("users").select("*",count='exact').eq('user_id',user_id).execute()
    count = request.count

    if count:
        return count>0
         
async def get_current_position(user_id):
    request = supabase.table("users").select("current_position").eq('user_id',user_id).execute()
    data = request.data
    
    if data:
        result = data[0]
        current_position = result['current_position']
        return current_position
    
async def get_nickname(user_id):
    request = supabase.table("users").select("nickname").eq('user_id',user_id).execute()
    data = request.data
    
    if data:
        result = data[0]
        nickname = result['nickname']
        return nickname
    
async def get_user_server(user_id):
    request = supabase.table("users").select("server").eq('user_id',user_id).execute()
    data = request.data
    
    if data:
        result = data[0]
        server = result['server']
        return server
    
async def get_user_server_nick(nickname):
    request = supabase.table("users").select("server").eq('nickname',nickname).execute()
    data = request.data
    
    if data:
        result = data[0]
        nickname = result['nickname']
        return nickname
    
async def get_user_department(user_id):
    request = supabase.table("users").select("department").eq('user_id',user_id).execute()
    data = request.data
    
    if data:
        result = data[0]
        department = result['department']
        return department
    
async def get_user_department_nick(nickname):
    request = supabase.table("users").select("department").eq('nickname',nickname).execute()
    data = request.data
    
    if data:
        result = data[0]
        department = result['department']
        return department
    
async def add_user_to_db(user_id,nickname,created_at,created_by,position,server,department):

    request = supabase.table("users").insert({
        "user_id": user_id,
        "nickname": nickname,
        "created_at": created_at,
        "created_by": created_by,
        "current_position": position,
        "server": server,
        "department": department
    }).execute()

async def update_password(password,user_id):
    request = supabase.table("users").update({"admin_pass":password}).eq("user_id",user_id).execute()

async def get_admin_access(user_id):
    request = supabase.table("users").select("admin_access").eq("user_id",user_id).execute()
    data = request.data
    
    if data:
        result = data[0]
        admin_access = result['admin_access']
        return admin_access

async def update_chat_id(chat_id,chat_full_name,server):
    request = supabase.table("server_info").update({f"{chat_full_name}":f"{chat_id}"}).eq("server",server).execute()

async def add_table_info(table_type,table_info,server):
    if table_type == 'admin':
        column = "admin_table"
    elif table_type == 'helper':
        column = "helper_table"
    else:
        column = "leader_table"

    request = supabase.table("server_info").update({
        f"{column}":table_info
    }).eq("server",server).execute()


async def get_management_chat(department,server):
    request = supabase.table("server_info").select(f"chat_{department}_id").eq("server",server).execute()
    data = request.data

    if data:
        result = data[0]
        management_id = result[f'chat_{department}_id']

        return management_id
    
async def get_user_stats(nickname,server):
    request = supabase.table("users").select("*").eq("nickname",nickname).eq("server",server).execute()
    data = request.data

    if data:
        result = data[0]
        
        return result

# async def add_user_to_sheets(nickname,user_id,position,created_by,created_at):
#     gc = gspread.service_account(filename='./data/credentials.json')
#     sh = gc.open_by_url('https://docs.google.com/spreadsheets/d/14FzPFJ5Y7Sh9KkmALKA6-jj7TgYA9oqWLoWbTvXmOHk/edit#gid=0')
#     worksheet = sh.sheet1
#     header_row = worksheet.row_values(1)
#     column_indices = {column_name: index + 1 for index, column_name in enumerate(header_row)}
#     next_row = len(worksheet.col_values(1)) + 1
    
#     worksheet.update_cell(next_row,column_indices["Nickname"],nickname)    
#     worksheet.update_cell(next_row,column_indices["user_id"],nickname)    
#     worksheet.update_cell(next_row,column_indices["Nickname"],nickname)    
#     worksheet.update_cell(next_row,column_indices["Nickname"],nickname)    


# Убрано,заменил на должности в .data/positions.py
# async def check_user_access(user_id):
#     request = supabase.table("users").select("user_access").eq('user_id',user_id).execute()
#     data = request.data
    
#     if data:
#         result = data[0]
#         current_position = result['user_access']
#         return current_position

