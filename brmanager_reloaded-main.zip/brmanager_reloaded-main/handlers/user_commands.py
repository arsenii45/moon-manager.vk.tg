import io
import base64
import requests
from aiogram import Router,Bot,F
from aiogram.types import Message,WebAppInfo,CallbackQuery,InputMediaPhoto
from aiogram.filters import Command,CommandObject,CommandStart
from aiogram. fsm. context import FSMContext
from aiogram.fsm.state import StatesGroup,State
import logging
import pytz

from utils.states import setpassword
from handlers.queries import *
from keyboards.builder import *
from data.positions import *
from datetime import datetime
from datetime import timedelta

router = Router()
moscow_tz = pytz.timezone('Europe/Moscow')
time = datetime.now(moscow_tz).strftime("%d/%m/%Y %H:%M:%S")

@router.message(CommandStart())
async def start_menu(message:Message):
    if await user_exists(message.from_user.id):
        current_position = await get_current_position(message.from_user.id)
        #nickname = await get_nickname(message.from_user.id)
        #mention = message.from_user.mention_html(name=nickname)
        #mention = message.from_user.mention_html(nickname)
        await message.answer(f"Вы попали в <b>Главное Меню</b>!",reply_markup=start_buttons(current_position))
        logging.info(f'{message.from_user.id} - Перешел в Главное Меню с помощью /start - {time}MSK')
    else:
        await message.answer("❌ Доступ к боту закрыт.")

@router.message(Command('setpassword'))
async def set_admin_panel_password(message: Message,state:FSMContext):
    current_position = await get_current_position(message.from_user.id)
    if current_position in top_management:
        await state.set_state(setpassword.password)
        await message.answer(text="Укажите новый пароль для админ-панели:\n\n<b>Примечание:</b> Установите пароль в формате цифр,который НИГДЕ не используються вами.")
        logging.info(f'{message.from_user.id} - Начал процесс обновления пароля для Админ-Панели - {time}MSK')
    else:
        await message.answer(text="❌ Доступ закрыт.")

@router.message(setpassword.password)
async def handle_password(message: Message, state: FSMContext):
    await state.update_data(password = message.text)
    password = message.text
    try:
        await update_password(password,message.from_user.id)
        await message.answer("✅ Успешно!")
        logging.info(f'{message.from_user.id} - Успешно обновил пароль для Админ-Панели - {time}MSK')
    except Exception as e:
        await message.answer(f"❗️ Произошла ошибка: {e}")
        logging.info(f'{message.from_user.id} - Произошла ошибка при обновление пароля: {e} - {time}MSK')


@router.message(Command("setchat"))
async def set_chat_id(message:Message):
    if await user_exists(message.from_user.id):
        await message.answer(text="Выберите тип чата:",reply_markup=select_chat())
        logging.info(f'{message.from_user.id} - Начал процесс привязки чата к отделу. - {time}MSK')
    else:
        await message.answer(text="Недоступно.")

@router.message(Command("stats"))
async def stats_command(message: Message,command: CommandObject):
    current_position = await get_current_position(message.from_user.id)
    if await user_exists(message.from_user.id) and current_position in top_management+f_management+h_management :
        cmd_arg = command.args.strip()
        logging.info(f'{message.from_user.id} - Прописал команду /stats {cmd_arg} - {time}MSK')
        if cmd_arg is None:
            await message.answer(text="❗️ Пропишите команду в формате /stats [nickname]")
            return

        admin_position = await get_current_position(message.from_user.id)
        #user_server = await get_user_server_nick(cmd_arg)
        user_department = await get_user_department_nick(cmd_arg)

        if len(cmd_arg.split()) == 1:
            if admin_position in f_management and user_department != 'Лидеры':
                await message.answer(text="❗️Просмотр статистики данного пользователя вам недоступна!")
                return
            elif admin_position in h_management and user_department != 'АП':
                await message.answer(text="❗️Просмотр статистики данного пользователя вам недоступна!")
                return
            elif admin_position in (h_management or f_management) and user_department == 'Администрация':
                await message.answer(text="❗️Просмотр статистики данного пользователя вам недоступна!")
                return
            elif admin_position in top_management and user_department in ['Администрация','АП','Лидеры']:
                pass
            else:
                pass

            server = await get_user_server(message.from_user.id)
            #nickname = await get_nickname(message.from_user.id)
            stats = await get_user_stats(cmd_arg,server)
            neaktiv = await get_user_neaktiv(message.from_user.id)
            current_month = datetime.now().month
            count_neaktiv = await get_user_neaktiv_info(message.from_user.id,current_month)
            days_with_neaktiv = await get_neaktiv_days(message.from_user.id)
            if stats is None:
                await message.answer(text=f"❌ Пользователь <b>{cmd_arg}</b> не найден в базе данных вашего сервера.")
                logging.info(f'{message.from_user.id} - Пользователь {cmd_arg} не найден в базе данных(/stats) - {time}MSK')
                return
            else:
                created_by = stats[2]
                current_position = stats[3]
                created_at = stats[5]
                department = stats[6]
                last_promotion = stats[4]
                stats_message = (
                    f"📊 Статистика <b>{cmd_arg}</b>:\n\n"
                    f"<b>Основная информация:</b>\n\n"
                    f"— Текущая должность: {current_position}\n"
                    f"— Создан пользователем: {created_by}\n"
                    f"— Создан в: {created_at}\n"
                    f"— Текущий отдел: {department}\n"
                    f"— Последнее повышения: {last_promotion}\n"
                    "<b>😴 Информация о текущим/последнем неактиве:</b>\n\n"
                    f"— Дата неактива: {neaktiv[5]}\n"
                    f"— Причина неактива: {neaktiv[6]}\n"
                    f"— Кол-во неактивов в месяце: {count_neaktiv}\n"
                    f"— Кол-во дней проведенных в неактиве: {days_with_neaktiv}"
                )
                await message.answer(text=stats_message,reply_markup=stats_markup(cmd_arg))
                logging.info(f'{message.from_user.id} - Успешно просмотрел статистику пользователя: {cmd_arg} - {time}MSK')
        else:
            await message.answer(text="❗️Пропишите команду в формате /stats [nickname]")
    else:
        await message.answer(text="Недоступно.")

@router.message(Command("gstats"))
async def handle_game_stats(message:Message,command:CommandObject):
    current_position = await get_current_position(message.from_user.id)
    if await user_exists(message.from_user.id) and current_position in top_management+h_management:
        cmd_arg = command.args
        if cmd_arg is None:
            await message.answer(text="❗️ Пропишите команду в формате /gstats [nickname]")
            return

        user_id = await get_user_id(cmd_arg)
        await message.answer(text=f"Выберите день за который желаете проверить игровую статистику {cmd_arg}",reply_markup=select_day_gstats(user_id))
        logging.info(f'{message.from_user.id} - Прописал команду /gstats {cmd_arg} - {time}MSK')
    else:
        await message.answer(text="❌ Доступ закрыт.")

@router.callback_query(lambda call: call.data.startswith("gstats_game_"))
async def handle_game_stats(call:CallbackQuery,):
    all_data = []
    if await user_exists(call.from_user.id):
        all_data.clear()
        day_param = call.data.split('_')[2]
        current_datetime = datetime.now()
        user_id = call.data.split('_')[3]

        department = await get_user_department(user_id)
        if day_param == 'week':
            start_of_week = current_datetime - timedelta(days=current_datetime.weekday())

            end_of_week = start_of_week + timedelta(days=5)

            min_date = start_of_week.strftime("%Y-%m-%d")
            end_date = end_of_week.strftime("%Y-%m-%d")

        elif day_param == 'month':
            start_of_month = datetime(current_datetime.year, current_datetime.month, 1)

            last_day_of_month = (datetime(current_datetime.year, current_datetime.month + 1, 1) - timedelta(days=1)).replace(hour=23, minute=59, second=59)

            min_date = start_of_month.strftime("%Y-%m-%d")
            end_date = last_day_of_month.strftime("%Y-%m-%d")

        else:
            day = int(day_param)

            target_date = datetime.now() - timedelta(days=day)
            min_date = target_date.strftime("%Y-%m-%d")
            end_date = min_date

        #min_date = "2024-01-08"
        #end_date = "2024-01-08"
        nickname = await get_nickname(user_id)
        server = await get_user_server(user_id)
        sessionid = await get_sessiond(server)

        if nickname:
            try:
                await call.message.edit_text(text=f"Выберите день за который желаете проверить игровую статистику {nickname}",reply_markup=None)
                await call.message.answer(text="Идет сбор информации, пожалуйста не взаимодействуйте с ботом.",)
                session = requests.Session()
                cookie = {'sessionid': sessionid}
                session.cookies.update(cookie)
                total_requests_count = 0
                category_id = ''
                params = {
                    'category_id__exact': category_id,
                    'player_name__exact': '',
                    'player_id__exact': '',
                    'player_ip__exact': '',
                    'transaction_amount__exact': '',
                    'balance_after__exact': '',
                    'transaction_desc__ilike': '',
                    'time__gte': f'{min_date}T00:00:00',
                    'time__lte': f'{end_date}T23:59:59',
                    'order_by': 'time',
                    'offset': 0,
                    'auto': False
                }

                if server == 'SPB':
                    url = f'https://logs.blackrussia.online/gslogs/24/api/list-game-logs/'
                elif server == 'BLACK':
                    url = f'https://logs.blackrussia.online/gslogs/10/api/list-game-logs/'
                elif server == 'ROSTOV':
                    url = f'https://logs.blackrussia.online/gslogs/29/api/list-game-logs/'
                elif server == 'ANAPA':
                    url = f'https://logs.blackrussia.online/gslogs/30/api/list-game-logs/'

                params['player_name__exact'] = nickname
                offset = 0
                total_count_report = 0
                connection_times = []
                disconnect_times = []

                while True:
                    params['offset'] = offset
                    response = session.get(url, params=params)

                    if response.status_code == 200:
                        data = response.json()
                        count = len(data)

                        if count == 0:
                            #await call.message.answer(text=f"Никаких данных не найдено для администратора {nickname} за указанный период {min_date}/{min_date}.")
                            break

                        total_count_report += count
                        total_requests_count += count

                        offset += count
                        all_data.extend(data)

                        for item in data:
                            event_time = datetime.fromisoformat(item['time'])
                            if 'Пользователь подключился' in item['transaction_desc']:
                                connection_times.append(event_time)
                            elif 'Пользователь отключился' in item['transaction_desc']:
                                disconnect_times.append(event_time)

                    else:
                        await call.message.answer(text=f"Ошибка при выполнении запроса: {response.status_code}")
                        break

                if total_requests_count == 0:
                    await call.message.answer(text=f"Никаких данных не найдено для администратора {nickname} за указанный период {min_date}/{min_date}.")
                    return

                report = sum(1 for item in all_data if 'transaction_desc' in item and 'Жалоба от' in item['transaction_desc'])
                ask = sum(1 for item in all_data if 'transaction_desc' in item and 'Вопрос' in item['transaction_desc'])
                events = sum(1 for item in all_data if 'transaction_desc' in item and 'Создал мероприятие' in item['transaction_desc'])
                jails = sum(1 for item in all_data if 'transaction_desc' in item and 'Посадил в деморган игрока' in item['transaction_desc'])
                mutes = sum(1 for item in all_data if 'transaction_desc' in item and 'Выдал мут игроку' in item['transaction_desc'])
                warns = sum(1 for item in all_data if 'transaction_desc' in item and 'Выдал предупреждение' in item['transaction_desc'])
                bans = sum(1 for item in all_data if 'transaction_desc' in item and 'Заблокировал игрока' in item['transaction_desc'])
                kicks = sum(1 for item in all_data if 'transaction_desc' in item and 'Кикнул' in item['transaction_desc'])
                p_bans = sum(1 for item in all_data if 'transaction_desc' in item and 'Навсегда заблокировал' in item['transaction_desc'])
                ps_bans = sum(1 for item in all_data if 'transaction_desc' in item and 'Навсегда тихо заблокировал' in item['transaction_desc'])

                total_bans = bans + p_bans + ps_bans



                if not connection_times or not disconnect_times:
                    rounded_total_session_time  = 0
                else:
                    connection_labels = [{"time": time, "label": "Пользователь подключился"} for time in connection_times]
                    disconnect_labels = [{"time": time, "label": "Пользователь отключился"} for time in disconnect_times]

                    all_labeled_times = connection_labels + disconnect_labels

                    all_labeled_times.sort(key=lambda x: x["time"], reverse=True)

                    session_durations = []
                    if all_labeled_times[0]["label"] == "Пользователь подключился" and all_labeled_times[-1]["label"] == "Пользователь подключился":
                        pass
                    if all_labeled_times[0]["label"] == "Пользователь подключился":
                        all_labeled_times = all_labeled_times[1:]
                    if all_labeled_times[0]["label"] == "Пользователь подключился" and all_labeled_times[-1]["label"] == "Пользователь отключился":
                        all_labeled_times = all_labeled_times[1:-1]
                    if all_labeled_times[-1]["label"] == "Пользователь отключился":
                        all_labeled_times = all_labeled_times[:-1]

                    session_durations = []
                    for i in range(0, len(all_labeled_times), 2):
                        connection_time = all_labeled_times[i]["time"]
                        disconnection_time = all_labeled_times[i + 1]["time"]
                        session_duration = disconnection_time - connection_time
                        session_durations.append(round(abs(session_duration.total_seconds() / 60)))

                    total_session_time = sum(session_durations)

                    current_time = datetime.now().strftime("%d-%m-%Y/%H:%M:%S")


                    stats_message = f"<b> ℹ️ Игровая статистика</b>: {nickname}\n\n"
                    stats_message += f"┃ Дата норматива: {min_date}/{end_date}\n\n"
                    stats_message += f"┃ Онлайн: {total_session_time} минут(-ы)\n"

                    if department == 'Администрация':
                            stats_message += f"┃ Банов: {total_bans}\n"
                            stats_message += f"┃ Киков: {kicks}\n"
                            stats_message += f"┃ Мутов: {mutes}\n"
                            stats_message += f"┃ Варнов: {warns}\n"
                            stats_message += f"┃ Ответов: {report}\n"
                            stats_message += f"┃ Мероприятий: {events}\n"
                            stats_message += f"┃ Джаилов: {jails}\n\n"


                    elif department == 'АП':
                            stats_message += f"┃ Ответов: {ask}\n"

                    stats_message += f"┃ <b>Общее количество действий за указанный промежуток: {total_count_report}</b>\n\n"
                    stats_message += f"┃ P.S Онлайн может отображаться некорректно.\n"
                    stats_message += f"┃ Локальное время сервера: {current_time}"
                    await call.message.answer(text=stats_message)
                    logging.info(f'{call.from_user.id} - Просмотрел статистику {nickname}(/gstats),Параметры: {min_date}/{end_date} - {time}MSK')
            except Exception as e:
                await call.message.answer(text=f"😔 Произошла ошибка: {e}")
                logging.info(f'{call.from_user.id} - Произошла ошибка при получение данных с логов(/gstats): {e},user_commands.py - {time}MSK')
    else:
        await call.answer(text="Недоступно.",show_alert=True)

@router.message(Command("test"))
async def test_command(message:Message):
    await message.answer(text=f'Hello,{message.from_user.first_name}')
