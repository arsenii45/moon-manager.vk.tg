from aiogram import Router
from aiogram.types import Message
import logging
import pytz
from handlers.queries import *
from datetime import datetime
from geopy.distance import geodesic
import re

router = Router()
moscow_tz = pytz.timezone('Europe/Moscow')
time = datetime.now(moscow_tz).strftime("%d/%m/%Y %H:%M:%S")


async def get_ip_info(ip_address):
    url = f"http://ip-api.com/json/{ip_address}?lang=ru"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        return data
    else:
        return None


@router.message()
async def echo(message: Message):
    args = message.text.split(" ")
    if await user_exists(message.from_user.id):
        if len(args) < 2:
            await message.answer("Функция проверки IP адресов сработала.Укажите два IP адреса.")
            return
        elif len(args) > 2:
            text = ("Максимальное количество предоставляемых IP-адресов - <b>два</b>\
                    \n\nЕсли вы предоставили два IP-адреса, убедитесь то что ваше сообщение не содержит лишних пробелов.")
            await message.answer(text)
            return

        ip_address_pattern = r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b'
        if not all(re.match(ip_address_pattern, ip) for ip in args):
            await message.reply("🤔 Кхм... ваше сообщение не похоже на IP-адреса.")
            return

        ip_info1 = await get_ip_info(args[0])
        ip_info2 = await get_ip_info(args[1])

        if ip_info1 is None or ip_info2 is None:
            await message.reply(f"Невозможно получить информацию о {ip_info1}&{ip_info2}")
            return
        else:
            distance = geodesic(
                (float(ip_info1['lat']), float(ip_info1['lon'])),
                (float(ip_info2['lat']), float(ip_info2['lon']))).kilometers

        if Exception == 'lat':
            await message.reply("Error: latitude.")

        info = f"<b>IP 1</b>: {ip_info1['query']}\n"
        info += f"Страна: {ip_info1['country']}\n"
        info += f"Город: {ip_info1['city']}\n\n"
        info += "<b>Информация о провайдере:</b>\n\n"
        info += f"Провайдер: {ip_info1['isp']}\n".title()
        info += f"Доп.инфа о провайдере: {ip_info1['org']}\n"
        info += f"Доп.инфа о провайдере: {ip_info1['as']}\n\n"

        info += ("➖➖➖➖➖➖➖➖➖➖➖➖➖➖  \n\n")

        info += f"<b>IP 2:</b> {ip_info2['query']}\n"
        info += f"Страна: {ip_info2['country']}\n"
        info += f"Город: {ip_info2['city']}\n\n"
        info += "<b>Информация о провайдере:</b>\n\n"
        info += f"Провайдер: {ip_info2['isp']}\n".title()
        info += f"Доп.инфа о провайдере: {ip_info2['org']}\n"
        info += f"Доп.инфа о провайдере: {ip_info2['as']}\n\n"
        info += f"Расстояние между двумя IP: <b>{distance:.2f}</b> километров"

        await message.answer(info)
        logging.info(f'{message.from_user.id} - Успешно просмотрел информацию о IP адресах: {args[0]}&{args[1]} - {time}MSK')
    else:
        await message.answer("❌ Доступ к данной функции вам недоступен.")
