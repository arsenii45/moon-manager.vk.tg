from aiogram.fsm.state import StatesGroup, State


class Adduser(StatesGroup):
    telegram_id = State()
    nickname = State()
    position = State()


class setpassword(StatesGroup):
    password = State()


class linktable(StatesGroup):
    table_type = State()
    table_info = State()


class sessionid(StatesGroup):
    sid = State()


class Neaktiv(StatesGroup):
    time = State()
    reason = State()


class mNeaktiv(StatesGroup):
    new_time = State()


class promotion(StatesGroup):
    screen = State()
    position = State()


class property(StatesGroup):
    p_nickname = State()
    info = State()
    goss_price = State()
    dolg = State()
    dolg_date = State()


class extra_work(StatesGroup):
    info = State()
    screens = State()
