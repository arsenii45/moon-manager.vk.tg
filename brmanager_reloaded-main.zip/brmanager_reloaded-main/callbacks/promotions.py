import requests
import io
from aiogram import Router,Bot,F
from aiogram. fsm. context import FSMContext
from aiogram.types import Message,CallbackQuery,InputMediaPhoto,InputMedia
from aiogram import types
from keyboards.builder import *
from handlers.queries import *
from aiogram.fsm.state import StatesGroup,State
import gspread
from data.positions import *
from utils.states import promotion
import logging
from datetime import datetime
import pytz

router = Router()
file_ids = []
IMGUR_CLIENT_ID = 'f3570ac6d1e6d10'
moscow_tz = pytz.timezone('Europe/Moscow')
time = datetime.now(moscow_tz).strftime("%d/%m/%Y %H:%M:%S")

@router.callback_query(lambda call: call.data == 'promotion')
async def promotion_start(call: CallbackQuery,state:FSMContext):
    if await user_exists(call.from_user.id):
        logging.info(f'{call.from_user.id} - Начал процесс подачи заявки на повышения - {time}MSK')
        await state.set_state(promotion.screen)
        await call.message.edit_text(text="Предоставьте скриншот игровой статистики. /astats -> Информация о администраторе.",reply_markup=cancel_button())
    else:
        await call.answer(text="Недоступно",show_alert=True)

@router.message(promotion.screen,F.photo)
async def handle_screen(message:Message,state:FSMContext):
    await state.update_data(screen=message.photo[-1].file_id)
    await state.set_state(promotion.position)
    
    current_position = await get_current_position(message.from_user.id)
    await message.answer(text="Выберите должность на которую желаете повысится:",reply_markup=promotion_markup(current_position))


@router.message(promotion.position,F.text.casefold().in_(promotion_positions))
async def handle_position(message:Message,state:FSMContext,bot:Bot):
    await state.update_data(position = message.text)
    data = await state.get_data()
    await state.clear()
    position = data['position']
    file_id = data['screen']
    
    file = await bot.get_file(file_id)
    file_path = file.file_path.replace("file_id=", f"{file_id}=")
    
    file_bytes = io.BytesIO() 
    await bot.download_file(file_path, destination=file_bytes)

    files = {
        'image': file_bytes.getvalue()
    }
    response = requests.post(
        'https://api.imgur.com/3/image', 
        headers={'Authorization': f'Client-ID {IMGUR_CLIENT_ID}'},
        files=files
    )
    
    imgur_url = response.json()['data']['link'] 
    server = await get_user_server(message.from_user.id)
    cursor.execute("SELECT user_id FROM users WHERE current_position IN ('Главный Администратор','Зам.Главного Администратора','Куратор Администрации') AND server = %s",(server,))
    result = cursor.fetchall()
    department = 'admin'
    department_db = 'Администрация'
    cursor.execute("SELECT id FROM promotions ORDER BY id DESC LIMIT 1")
    r_p_id = cursor.fetchone()
    if r_p_id:
        p_id = r_p_id[0] + 1
    else:
        p_id = 1

    #print(p_id)

    nickname = await get_nickname(message.from_user.id)
    current_position = await get_current_position(message.from_user.id)
    current_time_utc = datetime.utcnow()
    moscow_timezone = pytz.timezone('Europe/Moscow')
    timestamp = current_time_utc.replace(tzinfo=pytz.utc).astimezone(moscow_timezone).strftime("%d/%m/%Y %H:%M:%S")
    
    
    try:
        await promotion_insert(message.from_user.id,nickname,server,current_position,position,imgur_url,timestamp)
        await message.answer(text=f"✅ Успешно! Ваша заявка была отправлена Руководству.")
        logging.info(f'{message.from_user.id} - Отправил заявку на повышения,ID: {p_id} - {time}MSK')
    except Exception as e:
        await message.answer(text=f"😔 Произошла ошибка: {e}")
        logging.info(f'{message.from_user.id} - Произошла ошибка при обработки данных(Повышения): {e},ID: {p_id}  - {time}MSK')
        return
        
    
    for ids in result:
        id = ids[0]
        try:
            await bot.send_message(id,text=f'Пришла новая заявка на повышения от: <b>{nickname}</b>',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Рассмотреть заявку",web_app=WebAppInfo(url=f"{f_url}/promotions/{p_id}"))]]))
        except Exception as e:
            print(f"{e} - {id}")
            logging.info(f'{message.from_user.id} - Произошла ошибка при отправки сообщений руководству(Повышения) - {e} - TGManagement: {id},ID: {p_id} - {time}MSK')
            continue

@router.message(promotion.position,F.text=='Повышения недоступно!')
async def handle_cant_position(message:Message,state:FSMContext):
    current_position = await get_current_position(message.from_user.id)
    await message.answer(text=f"Повышение с <b>{current_position}</b> никуда невозможно. Если вы считаете что это ошибка, обратитесь к вашему Руководству.")
    await state.clear()


@router.message(promotion.position)
async def handle_position_incorrect(message:Message,state:FSMContext):
    await message.answer(text='Выберите опцию из предоставленных кнопок.')



@router.message(promotion.screen,~F.photo)
async def handle_screen_incorrect(message:Message,state:FSMContext):
    await message.answer(text="Предоставьте фотографию!")
