from aiogram import Router,Bot,F
from aiogram. fsm. context import FSMContext
from aiogram.types import Message,CallbackQuery
from keyboards.builder import *
from handlers.queries import *
from aiogram.fsm.state import StatesGroup,State
import gspread
from data.positions import *
from utils.states import Adduser
import logging
from datetime import datetime
import pytz

moscow_tz = pytz.timezone('Europe/Moscow')
time = datetime.now(moscow_tz).strftime("%d/%m/%Y %H:%M:%S")

router = Router()


#adding user to the bot
@router.callback_query(lambda call: call.data == 'add_user')
async def add_user(call: CallbackQuery, state: FSMContext):
    if await user_exists(call.from_user.id):
        await state.set_state(Adduser.telegram_id)
        logging.info(f'{call.from_user.id} - Начал процесс добавления пользователя - {time}MSK')
        await call.message.edit_text(text="Укажите Telegram ID в формате цифр.",reply_markup=cancel_button())
    else:
        await call.answer(text="Недоступно.",show_alert=True)

@router.message(Adduser.telegram_id)
async def handle_telegram_id(message: Message, state:FSMContext):
    if message.text.isdigit():
        await state.update_data(user_id=message.text)
        await state.set_state(Adduser.nickname)
        await message.answer("Укажите Nickname пользователя:")
    else:
        await message.answer("Telegram ID состоит только из чисел!\nВведите новое значение")

@router.message(Adduser.nickname)
async def handle_nickname(message: Message,state:FSMContext):
    await state.update_data(nickname = message.text)
    await state.set_state(Adduser.position)
    current_position =  await get_current_position(message.from_user.id)
    await message.answer(text="Выберите должность из кнопок ниже:",reply_markup=select_position(current_position))

@router.message(Adduser.position,F.text.casefold().in_(users_to_add)) 
async def handle_position(message:Message, state:FSMContext,bot:Bot):
    
    await state.update_data(position=message.text)

    data = await state.get_data()
    await state.clear()
    created_by = await get_nickname(message.from_user.id)
    current_time = datetime.now()


    user_id = data.get('user_id')
    nickname = data.get('nickname')
    position = data.get('position')
    if position in leaders_list:
        department = 'Лидеры'
        chat_department = 'leader'
    elif position == 'Младший Модератор':
        department = 'Администрация'
        chat_department = 'admin'
    elif position == 'Агент Поддержки':
        department = 'АП'
        chat_department = 'helper'
    
    server = await get_user_server(message.from_user.id)
    current_time_utc = datetime.utcnow()
    moscow_timezone = pytz.timezone('Europe/Moscow')
    current_time_moscow = current_time_utc.replace(tzinfo=pytz.utc).astimezone(moscow_timezone)
    management_chat = await get_management_chat(chat_department,server)
    created_at = current_time_moscow.strftime("%d/%m/%Y %H:%M:%S")
    user_profile_link = f'<a href="tg://user?id={user_id}">{nickname}</a>'    
    user_info = (
        "#LogsAddUser\n"
        f"✅ Пользователь успешно создан!\n\n"
        f"<b>Nickname</b>: {user_profile_link}\n"
        f"Telegram-ID: <code>{user_id}</code>\n"
        f"Должность: {position}\n"
        f"Отдел: {department}\n\n"
        f"Создан пользователем: <b>{created_by}</b>\n"
        f"Создан в: {created_at}\n"
    )
    table_link = await get_table_link(server,chat_department)
    try:
        gc = gspread.service_account(filename='./data/credentials.json')
        sh = gc.open_by_url(f"{table_link}")
        worksheet = sh.worksheet("Учётность состава")
        header_row = worksheet.row_values(1)
        column_indices = {column_name: index + 1 for index, column_name in enumerate(header_row)}
        next_row = len(worksheet.col_values(1)) + 1
        
        worksheet.update_cell(next_row,column_indices["NickName"],nickname)    
        worksheet.update_cell(next_row,column_indices["Должность"],position)    
        worksheet.update_cell(next_row,column_indices["Поставлен by"],created_by)    
        worksheet.update_cell(next_row,column_indices["Дата постановления"],created_at)    
        worksheet.update_cell(next_row,column_indices["Ответы"],0)    
        worksheet.update_cell(next_row,column_indices["Online"],0)    
        worksheet.update_cell(next_row,column_indices["Баллы"],0)    
        worksheet.update_cell(next_row,column_indices["Выговоры"],0)    
        worksheet.update_cell(next_row,column_indices["Предупреждение"],0)    
        worksheet.update_cell(next_row,column_indices["Устники"],0)    
        
        await add_user_to_db(user_id,nickname,created_at,created_by,position,server,department) 
        await message.answer(text=user_info)
        await bot.send_message(chat_id=management_chat,text=user_info)
        logging.info(f'{message.from_user.id} - Успешно создал пользователя {nickname} - {time}MSK')
    except Exception as e:
        await message.answer(text=f"Ошибка при добавлении пользователя: {e}")
        logging.info(f'{message.from_user.id} - Произошла ошибка при создании пользователя {e} - {time}MSK')
        return
    

@router.message(Adduser.position)
async def incorrect_position(message: Message, state: FSMContext):
    await message.reply("Выбери опцию из предоставленных кнопок.")