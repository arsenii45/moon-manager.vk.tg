from aiogram import Router,Bot,F
from aiogram. fsm. context import FSMContext
from aiogram.types import Message,CallbackQuery,InputMediaPhoto,InputMedia
from aiogram import types
from keyboards.builder import *
from handlers.queries import *
from aiogram.fsm.state import StatesGroup,State
from data.positions import *
from utils.states import property
import logging
from datetime import datetime
import pytz

router = Router()
moscow_tz = pytz.timezone('Europe/Moscow')
time = datetime.now(moscow_tz).strftime("%d/%m/%Y %H:%M:%S")

@router.callback_query(lambda call: call.data == 'property_transfer')
async def property_transfer(call: CallbackQuery,state:FSMContext):
    await call.message.edit_text(text="Укажите Nickname игрока с кем вы проводите транзакцию.",reply_markup=cancel_button())
    logging.info(f'{call.from_user.id} - Начал процесс подачи заявки на передачу имущества - {time}MSK')
    await state.set_state(property.p_nickname)

@router.message(property.p_nickname)
async def handle_pnick(message:Message,state:FSMContext):
    await state.update_data(p_nickname = message.text)
    await message.answer(text="Опишите транзакцию. Не забудьте цену за которую покупаете/продаете имущество.")
    await state.set_state(property.info)

@router.message(property.info)
async def property_info(message:Message,state:FSMContext):
    await state.update_data(info = message.text)
    await message.answer(text="Введите государственную стоимость имущества (если берете в долг - нажмите на кнопку).",reply_markup=ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text="Нету")]],one_time_keyboard=True,resize_keyboard=True))
    await state.set_state(property.goss_price)

@router.message(property.goss_price)
async def goss_price(message:Message,state:FSMContext):
    await state.update_data(goss_price = message.text)
    await message.answer(text="Укажите сумму которую берете в долг у игрока.(В противном случае нажмите на кнопку 'Не беру')",reply_markup=ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text="Не беру")]],one_time_keyboard=True,resize_keyboard=True))
    await state.set_state(property.dolg)

@router.message(property.dolg,F.text=='Не беру')
async def no_dolg(message:Message,state:FSMContext,bot:Bot):
    await state.update_data(dolg = message.text)
    data = await state.get_data()
    await state.clear()

    p_nickname = data['p_nickname']
    adm_nick = await get_nickname(message.from_user.id)
    server = await get_user_server(message.from_user.id)
    info = data['info']
    goss_price = data['goss_price']
    dolg = 'Не берет'
    dolg_date = 'Не берет'
    moscow_tz = pytz.timezone('Europe/Moscow')
    timestamp = datetime.now(moscow_tz).strftime("%d/%m/%Y %H:%M:%S")
    cursor.execute("SELECT user_id FROM users WHERE current_position IN ('Главный Администратор','Зам.Главного Администратора','Куратор Администрации') AND server = %s",(server,))
    result = cursor.fetchall()
    department = 'admin'
    department_db = 'Администрация'
    cursor.execute("SELECT id FROM promotions ORDER BY id DESC LIMIT 1")
    r_pt_id = cursor.fetchone()
    if r_pt_id:
        pt_id = r_pt_id[0] + 1
    else:
        pt_id = 1

    try:
        await property_transfer_insert(message.from_user.id,adm_nick,server,p_nickname,info,goss_price,dolg,dolg_date,timestamp)
        await message.answer(text=f"✅ Успешно! Ваша заявка была отправлена Руководству.")
        logging.info(f'{message.from_user.id} - Отправил заявку на передачу имущества,ID: {pt_id} - {time}MSK')
    except Exception as e:
        await message.answer(text=f"😔 Произошла ошибка: {e}")
        logging.info(f'{message.from_user.id} - Произошла ошибка при обработки данных(Передача имущества): {e},ID: {pt_id}  - {time}MSK')
        return
    
    for ids in result:
        id = ids[0]
        try:
            await bot.send_message(id,text=f'Пришла новая заявка на передачу имущества от: <b>{adm_nick}</b>',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Рассмотреть заявку",web_app=WebAppInfo(url=f"{f_url}/neaktiv/{pt_id}"))]]))
        except Exception as e:
            print(f"{e} - {id}")
            logging.info(f'{message.from_user.id} - Произошла ошибка при отправки сообщений руководству(Передача Имущества) - {e} - TGManagement: {id},ID: {pt_id} - {time}MSK')
            continue

@router.message(property.dolg)
async def no_dolg_date(message:Message,state:FSMContext):
    await state.update_data(dolg = message.text)
    await message.answer(text="Укажите дату возрата долга, в формате DD/MM/YYYY.",reply_markup=None)
    await state.set_state(property.dolg_date)

@router.message(property.dolg_date, F.text.regexp(r'^\d{2}/\d{2}/\d{4}$'))
async def dolg_date(message:Message,state:FSMContext,bot:Bot):
    await state.update_data(dolg_date = message.text)
    data = await state.get_data()
    await state.clear()

    p_nickname = data['p_nickname']
    adm_nick = await get_nickname(message.from_user.id)
    server = await get_user_server(message.from_user.id)
    info = data['info']
    goss_price = data['goss_price']
    dolg = data['dolg']
    dolg_date = data['dolg_date']
    moscow_tz = pytz.timezone('Europe/Moscow')
    timestamp = datetime.now(moscow_tz).strftime("%d/%m/%Y %H:%M:%S")
    cursor.execute("SELECT user_id FROM users WHERE current_position IN ('Главный Администратор','Зам.Главного Администратора','Куратор Администрации') AND server = %s",(server,))
    result = cursor.fetchall()
    department = 'admin'
    department_db = 'Администрация'
    cursor.execute("SELECT id FROM promotions ORDER BY id DESC LIMIT 1")
    r_pt_id = cursor.fetchone()
    if r_pt_id:
        pt_id = r_pt_id[0] + 1
    else:
        pt_id = 1

    try:
        await property_transfer_insert(message.from_user.id,adm_nick,server,p_nickname,info,goss_price,dolg,dolg_date,timestamp)
        await message.answer(text=f"✅ Успешно! Ваша заявка была отправлена Руководству.")
        logging.info(f'{message.from_user.id} - Отправил заявку на передачу имущества,ID: {pt_id} - {time}MSK')
    except Exception as e:
        await message.answer(text=f"😔 Произошла ошибка: {e}")
        logging.info(f'{message.from_user.id} - Произошла ошибка при обработки данных(Передача имущества): {e},ID: {pt_id}  - {time}MSK')
        return
    
    for ids in result:
        id = ids[0]
        try:
            await bot.send_message(id,text=f'Пришла новая заявка на передачу имущества от: <b>{adm_nick}</b>',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Рассмотреть заявку",web_app=WebAppInfo(url=f"{f_url}/neaktiv/{pt_id}"))]]))
        except Exception as e:
            print(f"{e} - {id}")
            logging.info(f'{message.from_user.id} - Произошла ошибка при отправки сообщений руководству(Передача Имущества) - {e} - TGManagement: {id},ID: {pt_id} - {time}MSK')
            continue

@router.message(property.dolg_date)
async def incorrect_dolg_date(message:Message,state:FSMContext):
    await message.answer(text="Укажите дату возрата долга, в формате DD/MM/YYYY.")