from aiogram import Router,Bot,F
from aiogram. fsm. context import FSMContext
from aiogram.types import Message,CallbackQuery,InputMediaPhoto,InputMedia
from aiogram import types
from keyboards.builder import *
from handlers.queries import *
from aiogram.fsm.state import StatesGroup,State
from data.positions import *
from utils.states import extra_work
import logging
from datetime import datetime
import pytz
import gspread

router = Router()
moscow_tz = pytz.timezone('Europe/Moscow')
time = datetime.now(moscow_tz).strftime("%d/%m/%Y %H:%M:%S")

@router.callback_query(lambda call: call.data == 'extra_work')
async def start_extra_work(call:CallbackQuery,state:FSMContext):
    await state.set_state(extra_work.info)
    logging.info(f'{call.from_user.id} - Начал процесс подачи заявления на доп.работу - {time}MSK')
    await call.message.edit_reply_markup(reply_markup=None)
    await call.message.answer(text="Опишите проделанную доп.работу за день.",reply_markup=cancel_button())

@router.message(extra_work.info)
async def handle_info(message:Message,state:FSMContext):
    await state.update_data(info = message.text)
    await state.set_state(extra_work.screens)
    await message.answer(text="Предоставьте ссылку на скриншоты доп.работы(Imgur/Google Photos).")

@router.message(extra_work.screens,F.text.startswith("https://"))
async def handle_screens(message:Message,state:FSMContext,bot:Bot):
    await state.update_data(screens  = message.text)
    data = await state.get_data()
    await state.clear()
    info = data['info']
    screens_link = data['screens']
    nickname = await get_nickname(message.from_user.id)
    department = await get_user_department(message.from_user.id)
    server = await get_user_server(message.from_user.id)
    if department == 'Лидеры':
        cursor.execute(f"SELECT user_id FROM users WHERE current_position IN ('ГС ГОСС','ЗГС ГОСС','ГС ОПГ','ЗГС ОПГ') AND server = %s",(server,))
        department = 'leader'
        department_db = "Лидеры"
    # elif department == 'АП':
    #     cursor.execute(f"SELECT user_id FROM users WHERE current_position IN ('ГС АП','ЗГС АП') AND server = %s",(server,))
    #     department = 'helper'
    #     department_db = 'АП'
    else:
        cursor.execute(f"SELECT user_id FROM users WHERE current_position IN ('Главный Администратор','Зам.Главного Администратора','Куратор Администрации') AND server = %s",(server,))
        department = 'admin'
        department_db = 'Администрация'
    
    result = cursor.fetchall()

    cursor.execute("SELECT id FROM extra_work ORDER BY id DESC LIMIT 1")
    r_id = cursor.fetchone()
    if r_id:
        r_id = r_id[0] + 1
    else:
        r_id = 1

    management_chat = await get_management_chat(department,server)
    
    try:
        await extra_work_insert(message.from_user.id,nickname,server,department_db,info,screens_link,time)
        await message.answer(text=f"✅ Ваша отчетность была успешно отправлена руководству!")
        logging.info(f'{message.from_user.id} - Отправил отчет на доп.работу,ID: {r_id}. - {time}MSK')
        info_message = f"#Report\n\n"
        info_message += f"<b>01.Nickname:</b> {nickname}\n<b>02.Информация:</b> {info}"
        await bot.send_message(management_chat,text=info_message,reply_markup=extra_work_markup(screens_link=screens_link,r_id=r_id),parse_mode="HTML")
        logging.info(f'{message.from_user.id} - Отчет успешно отправился в беседу руководства,ID: {r_id}. - {time}MSK')
    except Exception as e:
        await message.answer(f"😔 Произошла ошибка: {e}")
        logging.info(f'{message.from_user.id} - Произошла ошибка при обработки данных(Доп.работа): {e},ID: {r_id}  - {time}MSK')
        return

        # for ids in result:
        #     id = ids[0]
        #     try:
        #         await bot.send_message(id,text=f'<b>{nickname}</b> отправил отчет о доп.работе.',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Рассмотреть заявку",web_app=WebAppInfo(url=f"{f_url}/neaktiv/{r_id}"))]]))
        #     except Exception as e:
        #         print(f"{e} - {id}")
        #         logging.info(f'{message.from_user.id} - Произошла ошибка при отправки сообщений руководству(Доп.работа) - {e} - TGManagement: {id},ID: {r_id} - {time}MSK')
        #         continue
        
        conn.close()


@router.message(extra_work.screens,~F.text.startswith("https://"))
async def wrong_input(message:Message,state:FSMContext):
    await message.answer(text="❗ Предоставьте ссылку которая начинается на https://...")

@router.callback_query(lambda call: call.data.startswith("extra_work_") or call.data.startswith("ex_work_"))
async def handle_buttons(call:CallbackQuery,bot:Bot):
    if call.data.startswith("extra_work"):
        status = call.data.split("_")[2]
        id = call.data.split("_")[3]

        if status == 'accept':
            await call.message.edit_text(text="Выберите опцию из кнопок:",reply_markup=extra_work_edit(id))
        else:
            cursor.execute("SELECT user_id FROM extra_work WHERE id = %s",(id,))
            user_id = cursor.fetchone[0]
            admin_nick = await get_nickname(call.from_user.id)
            try:
                await bot.send_message(user_id,text=f"Ваш отчет на доп.активность был отказан администратором - {admin_nick}")
                logging.info(f'{call.from_user.id} - Отчет успешно отказан (Доп.работа),ID: {id}. - {time}MSK')
            except Exception as e:
                await call.answer(text=f"Не удалось отправить сообщение: {e}",show_alert=True)
                logging.info(f'{call.from_user.id} - Произошла ошибка при отправки сообщения пользователю(Доп.работа) - {e} - TGid: {user_id},ID: {id} - {time}MSK')
    
    elif call.data.startswith("ex_work"):
        points = call.data.split("_")[2]
        id = call.data.split("_")[3]
        cursor.execute("SELECT department,server,nickname,info,screens_link FROM extra_work WHERE id = %s",(id,))
        result = cursor.fetchone()
        if result:
            department = result[0]
            server = result[1]
            nickname = result[2]
            info = result[3]
            screens_link = result[4]

        if department == 'Администрация':
            department_db = 'admin'
        else:
            department_db = 'leader'
        
        admin_nick = await get_nickname(call.from_user.id)
        table_link = await get_table_link(server,department_db)

        gc = gspread.service_account(filename='./data/credentials.json')
        sh = gc.open_by_url(table_link)
        worksheet = sh.worksheet("Учётность состава")
        header_row = worksheet.row_values(1)
        column_indices = {column_name: index + 1 for index, column_name in enumerate(header_row)}
        cells = worksheet.findall(nickname)
        if cells: 
            cell = cells[0]
            row = cell.row
            existing_points_cell = worksheet.cell(row, column_indices['Баллы']).value
            value_to_update = int(existing_points_cell) + int(points)
            worksheet.update_cell(row,column_indices['Баллы'],value_to_update)
            info_message = f"#Report\n"
            info_message += f'Статус: Одобрено by: {admin_nick}\n'
            info_message += f"<b>01.Nickname:</b> {nickname}\n<b>02.Информация:</b> {info}"
            await call.message.edit_text(info_message,reply_markup=None)
            logging.info(f'{call.from_user.id} - Отчет успешно одобрен(Доп.работа),ID: {id} - {time}MSK')
        else:
            await call.answer(text=f"{nickname} не найден в таблице состава.",show_alert=True)
        
    

@router.callback_query(lambda call: call.data.startswith('back_to_extra_work_'))
async def handle_back_button(call:CallbackQuery):
    id = call.data.split('_')[4]
    cursor.execute("SELECT nickname,info,screens_link FROM extra_work WHERE id = %s",(id,))
    result = cursor.fetchone()
    if result:
        nickname = result[0]
        info = result[1]
        screens_link = result[2]
    else:
        await call.answer(text='ID заявки неопределен.',show_alert=True)
        return

    info_message = f"#Report\n\n"
    info_message += f"<b>01.Nickname:</b> {nickname}\n<b>02.Информация:</b> {info}"
    await call.message.edit_text(text=info_message,reply_markup=extra_work_markup(screens_link=screens_link,r_id=id))
    

    

