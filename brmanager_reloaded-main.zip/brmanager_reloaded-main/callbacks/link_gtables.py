from aiogram import Router, Bot, F
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery
from keyboards.builder import *
from handlers.queries import *
from aiogram.fsm.state import StatesGroup, State
import gspread
from gspread_formatting import *
from data.positions import *
from utils.states import linktable
import pytz
import logging

from datetime import datetime

router = Router()
moscow_tz = pytz.timezone('Europe/Moscow')
time = datetime.now(moscow_tz).strftime("%d/%m/%Y %H:%M:%S")


@router.callback_query(lambda call: call.data.startswith("link_table_"))
async def link_table(call: CallbackQuery, state: FSMContext):
    if await user_exists(call.from_user.id):
        table_type = call.data.split("_")[2]
        await state.update_data(table_type=table_type)
        await state.set_state(linktable.table_info)
        logging.info(
            f'{call.from_user.id} - Начал процесс подключение гугл-таблицы, Тип таблицы: {table_type} - {time}MSK')
        await call.message.answer(
            text="Для начала, выдайте доступ данному Google аккаунту к редактированию таблицы - "
                 "\nbr-manager@brmanager.iam.gserviceaccount.com\n\nПосле, скопируйте ссылку на вашу таблицу и "
                 "отправьте ее мне.",
            reply_markup=cancel_button())
    else:
        await call.answer(text="Недоступно.", show_alert=True)


@router.message(linktable.table_info, F.text.startswith('https://docs.google.com/spreadsheets/'))
async def handle_table_info(message: Message, state: FSMContext, bot: Bot):
    await state.update_data(table_info=message.text)
    data = await state.get_data()
    await state.clear()

    table_type = data.get("table_type")
    table_info = data.get("table_info")
    server = await get_user_server(message.from_user.id)
    management_chat = await get_management_chat(table_type, server)

    try:
        await message.answer(text="Процесс начался, ожидайте.")
        await add_table_info(table_type, table_info, server)
        gc = gspread.service_account(filename='./data/credentials.json')
        spreadsheet = gc.open_by_url(table_info)
        worksheet = spreadsheet.add_worksheet(title='Учётность состава', rows=500, cols=18)
        header_row = [
            'NickName', 'Должность', 'Кем поставлен', 'Дата постановления', 'Текущий/Последний неактив',
            'Последние повышения',
            'Ответы', 'Online', 'Баллы', 'Выговоры', 'Предупреждение', 'Устники',
            'PC', 'Возраст', 'Час.пояс', 'Discord', 'VK', 'Forum', 'Email'
        ]

        worksheet.format("A1:S500", {
            "backgroundColor": {
                "red": 1.0,
                "green": 1.0,
                "blue": 1.0
            },
            "horizontalAlignment": "CENTER",
            "textFormat": {
                "foregroundColor": {
                    "red": 0.0,
                    "green": 0.0,
                    "blue": 0.0
                },
                "fontSize": 11,
                "bold": True,
                "fontFamily": "Oswald"
            }
        })

        worksheet.insert_row(header_row, index=1)
        set_frozen(worksheet, cols=1)
        set_frozen(worksheet, rows=1)
        set_column_width(worksheet, 'A', 127)
        set_column_width(worksheet, 'B', 155)
        set_column_width(worksheet, 'C', 127)
        set_column_width(worksheet, 'D', 155)
        set_column_width(worksheet, 'E', 311)
        set_column_width(worksheet, 'F', 152)
        set_column_width(worksheet, 'G', 73)
        set_column_width(worksheet, 'H', 65)
        set_column_width(worksheet, 'I', 69)
        set_column_width(worksheet, 'J', 91)
        set_column_width(worksheet, 'K', 115)
        set_column_width(worksheet, 'L', 91)
        set_column_width(worksheet, 'M', 73)
        set_column_width(worksheet, 'N', 56)
        set_column_width(worksheet, 'O', 65)
        set_column_width(worksheet, 'P', 53)
        set_column_width(worksheet, 'Q', 73)
        set_column_width(worksheet, 'R', 82)
        set_column_width(worksheet, 'S', 201)
        new_worksheet = spreadsheet.add_worksheet(title="Учёт снятых", rows=500, cols="18")
        new_worksheet.format("A1:S500", {
            "backgroundColor": {
                "red": 1.0,
                "green": 1.0,
                "blue": 1.0
            },
            "horizontalAlignment": "CENTER",
            "textFormat": {
                "foregroundColor": {
                    "red": 0.0,
                    "green": 0.0,
                    "blue": 0.0
                },
                "fontSize": 11,
                "bold": True,
                "fontFamily": "Oswald"
            }
        })
        new_worksheet.insert_row(
            ['NickName', 'Должность', 'Кем поставлен', 'Дата постановления', 'Снят в', 'Снят кем', 'Причина',
             'Ответы', 'Online', 'Баллы', 'Выговоры', 'Предупреждение', 'Устники',
             'PC', 'Возраст', 'Час.пояс', 'Discord', 'VK', 'Forum', 'Email'], index=1)
        set_frozen(new_worksheet, rows=1)
        set_frozen(worksheet, cols=1)
        set_column_width(new_worksheet, 'A', 127)
        set_column_width(new_worksheet, 'B', 155)
        set_column_width(new_worksheet, 'C', 127)
        set_column_width(new_worksheet, 'D', 155)
        set_column_width(new_worksheet, 'E', 155)
        set_column_width(new_worksheet, 'F', 127)
        set_column_width(new_worksheet, 'G', 110)
        set_column_width(new_worksheet, 'H', 73)
        set_column_width(new_worksheet, 'I', 65)
        set_column_width(new_worksheet, 'J', 69)
        set_column_width(new_worksheet, 'K', 115)
        set_column_width(new_worksheet, 'L', 115)
        set_column_width(new_worksheet, 'M', 115)
        set_column_width(new_worksheet, 'N', 58)
        set_column_width(new_worksheet, 'O', 66)
        set_column_width(new_worksheet, 'P', 58)
        set_column_width(new_worksheet, 'Q', 71)
        set_column_width(new_worksheet, 'R', 56)
        set_column_width(new_worksheet, 'S', 160)

        await message.answer(text="✅ Таблица успешно привязана!")
        logging.info(
            f'{message.from_user.id} - Успешно привязал таблицу {table_info}, Тип таблицы: {table_type}  - {time}MSK')
    except Exception as e:
        await message.answer(text=f"Произошла ошибка: {e}")
        logging.info(
            f'{message.from_user.id} - Произошла ошибка при подключении гугл таблицы: {e},Тип таблицы: {table_type}  - {time}MSK')
        return


@router.message(linktable.table_info)
async def table_info_incorrect(message: Message, state: FSMContext):
    await message.answer(text="Предоставьте ссылку которая начинается на https://docs.google.com/spreadsheets/...")
