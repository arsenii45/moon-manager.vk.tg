from aiogram import Router,Bot,F
from aiogram. fsm. context import FSMContext
from aiogram.types import Message,CallbackQuery,WebAppInfo
from keyboards.builder import *
from handlers.queries import *
from aiogram.fsm.state import StatesGroup,State
import gspread
from data.positions import *
from utils.states import Neaktiv,mNeaktiv

import logging

from datetime import datetime
import pytz

router = Router()
moscow_tz = pytz.timezone('Europe/Moscow')
time = datetime.now(moscow_tz).strftime("%d/%m/%Y %H:%M:%S")

@router.callback_query(lambda call: call.data=='neaktiv')
async def neaktiv_start(call:CallbackQuery,state:FSMContext):
    logging.info(f'{call.from_user.id} - Начал процесс подачи заявки на неактив. - {time}MSK')
    await state.set_state(Neaktiv.time)
    await call.message.edit_text(text="Укажите период неактивности в формате DD.MM.YYYY/DD.MM.YYYY",reply_markup=cancel_button())

@router.message(Neaktiv.time,F.text.regexp(r'^\d{2}\.\d{2}\.\d{4}\/\d{2}\.\d{2}\.\d{4}$'))
async def handle_time(message:Message,state:FSMContext):
    await state.update_data(time=message.text)
    await state.set_state(Neaktiv.reason)
    await message.answer(text="Укажите причину для неактива или выберите из кнопок ниже.",reply_markup=neaktiv_markup())

@router.message(Neaktiv.reason)
async def handle_reason(message:Message,state:FSMContext,bot:Bot):
    await state.update_data(reason=message.text)
    data = await state.get_data()
    await state.clear()
    time = data['time']
    reason = data['reason']
    start_date, end_date = map(lambda x: datetime.strptime(x, '%d.%m.%Y'), time.split('/'))
    num_days = (end_date - start_date).days
    nickname = await get_nickname(message.from_user.id)
    department = await get_user_department(message.from_user.id)
    server = await get_user_server(message.from_user.id)
    if department == 'Лидеры':
        cursor.execute(f"SELECT user_id FROM users WHERE current_position IN ('ГС ГОСС','ЗГС ГОСС','ГС ОПГ','ЗГС ОПГ') AND server = %s",(server,))
        department = 'leader'
        department_db = "Лидеры"
    elif department == 'АП':
        cursor.execute(f"SELECT user_id FROM users WHERE current_position IN ('ГС АП','ЗГС АП') AND server = %s",(server,))
        department = 'helper'
        department_db = 'АП'
    else:
        cursor.execute(f"SELECT user_id FROM users WHERE current_position IN ('Главный Администратор','Зам.Главного Администратора','Куратор Администрации') AND server = %s",(server,))
        department = 'admin'
        department_db = 'Администрация'
    
    result = cursor.fetchall()
    cursor.execute("SELECT id FROM neaktiv ORDER BY id DESC LIMIT 1")
    n_id = cursor.fetchone()
    if n_id:
        n_id = n_id[0] + 1
    else:
        n_id = 1
    management_chat = await get_management_chat(department,server)
    month = datetime.now().month

        
    try:
        await neaktiv_insert(message.from_user.id, nickname, time, reason, department_db, server, month, num_days)
        await message.answer(text=f"✅ Ваша заявка была успешно отправлена руководству!\n\nИнформация о неактиве:\n\n<b>Даты неактива:</b> {time}\n<b>Причина:</b> {reason}")
        logging.info(f'{message.from_user.id} - Отправил заявку на неактив,ID: {n_id}. - {time}MSK')
        #await bot.send_message(management_chat,text="#New\n\nПришла новая заявка на неактив!")
    except Exception as e:
        await message.answer(f"😔 Произошла ошибка: {e}")
        logging.info(f'{message.from_user.id} - Произошла ошибка при обработки данных(Неактив): {e},ID: {n_id}  - {time}MSK')
        return
    
    for ids in result:
        id = ids[0]
        try:
            await bot.send_message(id,text=f'Пришла новая заявка на неактив от: <b>{nickname}</b>',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Рассмотреть заявку",web_app=WebAppInfo(url=f"{f_url}/neaktiv/{n_id}"))]]))
        except Exception as e:
            print(f"{e} - {id}")
            logging.info(f'{message.from_user.id} - Произошла ошибка при отправки сообщений руководству(Неактив) - {e} - TGManagement: {id},ID: {n_id} - {time}MSK')
            continue
        
        
@router.message(Neaktiv.time)
async def incorrect_time(message:Message,state:FSMContext):
    await message.answer(text="❗Некорректный формат!\n\nУкажите период неактивности в формате DD.MM.YYYY/DD.MM.YYYY")

#neaktiv edit handler
@router.callback_query(lambda call: call.data == 'manage_neaktiv')
async def manage_neaktiv(call:CallbackQuery,state:FSMContext):
    if await user_exists(call.from_user.id):
        await state.set_state(mNeaktiv.new_time)
        await call.message.edit_text(text="Укажите новые даты неактива в формате DD.MM.YYYY/DD.MM.YYYY или отмените его.",reply_markup=cancel_neaktiv())
    else:
        await call.answer(text="Недоступно.",show_alert=True)


@router.message(mNeaktiv.new_time,F.text.regexp(r'^\d{2}\.\d{2}\.\d{4}\/\d{2}\.\d{2}\.\d{4}$'))
async def handle_new_time(message:Message,state:FSMContext,bot:Bot):
    await state.update_data(new_time = message.text)
    data = await state.get_data()
    new_time_start = datetime.strptime(data['new_time'].split('/')[0], '%d.%m.%Y')
    new_time_end = datetime.strptime(data['new_time'].split('/')[1], '%d.%m.%Y')
    
    await state.clear()
    result = await get_user_neaktiv(message.from_user.id)
    id = result[0]
    nickname = result[2]
    department = result[3]
    server = result[4]
    reason = result[8]
    if department == 'Администрация':
        department = 'admin'
    elif department == 'АП':
        department = 'helper'
    else:
        department = 'leader'
    table_link = await get_table_link(server,department)
    management_chat = await get_management_chat(department,server)
    old_time_start = datetime.strptime(result[5].split('/')[0], '%d.%m.%Y')
    old_time_end = datetime.strptime(result[5].split('/')[1], '%d.%m.%Y')
    if old_time_start <= new_time_start <= old_time_end and new_time_end <= old_time_end:
        new_time_combined = f"{new_time_start.strftime('%d.%m.%Y')}/{new_time_end.strftime('%d.%m.%Y')}"
        value_to_update = f"{new_time_combined},{reason}"
        try:
            await update_neaktiv(new_time_combined,id)
            gc = gspread.service_account(filename='./data/credentials.json')
            sh = gc.open_by_url(table_link)
            worksheet = sh.worksheet("Учётность состава")
            header_row = worksheet.row_values(1)
            column_indices = {column_name: index + 1 for index, column_name in enumerate(header_row)}
            cells = worksheet.findall(nickname)
            if cells:
                cell = cells[0]
                row = cell.row
                worksheet.update_cell(row,column_indices['Текущий/Последний неактив'],value_to_update)
            await bot.send_message(management_chat,text=f"#NeaktivUpdate\n\n<b>{nickname}</b> изменил дату(ы) своего неактива с {result[5]} на {new_time_combined}.")
            await message.answer(text=f"✅ Успешно! Вы обновили свой неактив с <b>{result[5]}</b> на <b>{new_time_combined}</b>")
        except Exception as e:
            await message.answer(text=f"😔 Произошла ошибка: {e}")
            return
    else:
        await message.answer(text="❌ Невозможно обновить неактив.")
    

@router.message(mNeaktiv.new_time)
async def incorrect_time(message:Message,state:FSMContext):
    await message.answer(text="❗Некорректный формат!\n\nУкажите период неактивности в формате DD.MM.YYYY/DD.MM.YYYY")