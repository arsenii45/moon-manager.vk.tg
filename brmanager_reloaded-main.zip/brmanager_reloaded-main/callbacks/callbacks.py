from aiogram import Router,Bot,F
from aiogram. fsm. context import FSMContext
from aiogram.types import Message,CallbackQuery,ChatShared
from keyboards.builder import *
from handlers.queries import *
from aiogram.fsm.state import StatesGroup,State
from aiogram.types.chat import Chat
import pytz
import logging
from datetime import datetime

from data.positions import *
from utils.states import Adduser,sessionid

moscow_tz = pytz.timezone('Europe/Moscow')
time = datetime.now(moscow_tz).strftime("%d/%m/%Y %H:%M:%S")

router = Router()

# mainmenu + cancelprocess
@router.callback_query(lambda call: call.data in ['admin_panel','admins_menu','helpers_menu','leaders_menu','cancel_process'])
async def handle_menu_buttons(call: CallbackQuery,state: FSMContext):
    if await user_exists(call.from_user.id):
        current_position =  await get_current_position(call.from_user.id)
        if call.data == 'cancel_process':
            await state.clear()
            await call.message.edit_text("✅ Процесс успешно отменен!")
            logging.info(f'{call.from_user.id} - Отменил все текущие процессы с помощью кнопки(Отменить) - {time}MSK')
        elif call.data == 'admin_panel':
            #admin_access = await get_admin_access(call.from_user.id)
            await call.message.edit_text("Выберите нужный раздел:",reply_markup=admin_panel(current_position))
            logging.info(f'{call.from_user.id} - Перешел в панель управления. - {time}MSK')
        elif call.data == 'admins_menu':
            if current_position in top_management:
                await call.message.edit_text("Выберите действие:",reply_markup=admins_menu(current_position))
                logging.info(f'{call.from_user.id} - Перешел в ADMIN MENU. - {time}MSK')
            else:
                await call.answer("Доступ к данной функции закрыт.",show_alert=True)
        elif call.data == 'leaders_menu':
            current_position =  await get_current_position(call.from_user.id)
            if current_position in top_management + f_management:
                await call.message.edit_text("Выберите действие:",reply_markup=leaders_menu(current_position))
                logging.info(f'{call.from_user.id} - Перешел в LEADERS MENU. - {time}MSK')
            else:
                await call.answer("Доступ к данной функции закрыт.",show_alert=True)
        elif call.data == 'helpers_menu':
            current_position =  await get_current_position(call.from_user.id)
            if current_position in top_management + h_management:
                await call.message.edit_text("Выберите действие:",reply_markup=helpers_menu(current_position))
                logging.info(f'{call.from_user.id} - Перешел в HELPERS MENU. - {time}MSK')
            else:
                await call.answer("Доступ к данной функции закрыт.",show_alert=True)
    else:
        await call.answer(text="Недоступно.",show_alert=True)

@router.callback_query(lambda call: call.data == 'main_menu')
async def main_menu(call: CallbackQuery):
    if await user_exists(call.from_user.id):
        current_position = await get_current_position(call.from_user.id)
        await call.message.edit_text("Вы попали в <b>Главное Меню</b>!",reply_markup=start_buttons(current_position))
        logging.info(f'{call.from_user.id} - Перешел в Главное меню с помощью кнопки(main_menu) - {time}MSK')
    else:
        await call.message.answer("❌ Доступ к боту закрыт.")

#setchat
@router.callback_query(lambda call: call.data.startswith("chat_"))
async def handle_set_chat(call: CallbackQuery,bot:Bot):
    if await user_exists(call.from_user.id):
        chat_full_name = call.data.split()[0]
        chat_type = call.data.split("_")[1]
        server = await get_user_server(call.from_user.id)
        if chat_type=="admin":
            chat_name = "Административный"
        elif chat_type == 'leader':
            chat_name = "Лидерский"
        else:
            chat_name = "Хэлперский"
        chat_id = call.message.chat.id
        try:
            await update_chat_id(chat_id,chat_full_name,server)
            await call.message.answer(text=f"✅ {chat_name} чат успешно установлен!")
            logging.info(f'{call.from_user.id} - Успешно привязал {chat_name}. - {time}MSK')
        except Exception as e:
            await call.message.answer(text=f"😔 Произошла ошибка: {e}")
            logging.info(f'{call.from_user.id} - Произошла ошибка при привязки чата к отделу {e},Тип чата:{chat_type}. - {time}MSK')
            return
    else:
        await call.answer(text="Недоступно.",show_alert=True)

#stats_handler
@router.callback_query(lambda call: call.data == 'my_stats')
async def user_stats_choice(call: CallbackQuery):
    if await user_exists(call.from_user.id):
        await call.message.edit_text(text="Выберите статистику для просмотра:",reply_markup=my_stats_choice())
        logging.info(f'{call.from_user.id} - Перешел в панель просмотра статистики. - {time}MSK')
    else:
        await call.answer(text="Недоступно.",show_alert=True)

#setsessionid
@router.callback_query(lambda call: call.data == 'sessionid')
async def update_sessionid(call: CallbackQuery,state: FSMContext):
    await state.set_state(sessionid.sid)
    logging.info(f'{call.from_user.id} - Начал процесс обновления SessionID. - {time}MSK')
    await call.message.edit_text(text="Укажите новый Session ключ:",reply_markup=cancel_button())

@router.message(sessionid.sid,F.text.len()>=10)
async def handle_sessionid(message:Message,state:FSMContext):
    await state.update_data(sessionid=message.text)
    data = await state.get_data()
    server = await get_user_server(message.from_user.id)
    await state.clear()

    sessionid = data['sessionid']
    try:
        await update_sessionid_db(sessionid,server)
        await message.answer(text=f"✅ SessionID успешно обновлен на: {sessionid}")
        logging.info(f'{message.from_user.id} - Успешно обновил SessionID для сервера {server}. - {time}MSK')
    except Exception as e:
        await message.answer(text=f"😔 Произошла ошибка: {e}")
        logging.info(f'{message.from_user.id} - Произошла ошибка при обновление SessionID {e}. - {time}MSK')
        return

@router.message(sessionid.sid)
async def handle_wrong(message:Message,state:FSMContext):
    await message.answer(text="❗ Неправильный формат!")

#setrequests
@router.callback_query(lambda call: call.data == 'requests')
async def requests_btn(call:CallbackQuery):
    if await user_exists(call.from_user.id):
        department = await get_user_department(call.from_user.id)
        await call.message.edit_text(text="Выберите действие:",reply_markup=requests_panel(department))
        logging.info(f'{call.from_user.id} - Перешел в панель «Подачи заявлений» - {time}MSK')
    else:
        await call.answer(text="Недоступно.",show_alert=True)